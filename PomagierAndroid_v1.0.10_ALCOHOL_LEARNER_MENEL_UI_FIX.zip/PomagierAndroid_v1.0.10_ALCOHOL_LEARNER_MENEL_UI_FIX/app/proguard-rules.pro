-keepclassmembers class pl.don.pomagier.AndroidBridge {
    @android.webkit.JavascriptInterface <methods>;
}
