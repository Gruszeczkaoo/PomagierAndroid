package pl.don.pomagier

import android.content.Context
import com.chaquo.python.Python
import com.chaquo.python.android.AndroidPlatform
import org.json.JSONObject
import java.io.File
import java.util.concurrent.CountDownLatch
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean

object BrainManager {
    const val BRIDGE_TOKEN = "cReAmap0WBb6Sj6cGa5S_1shC-BRzY_x"

    private val started = AtomicBoolean(false)
    private val readyLatch = CountDownLatch(1)
    private val initExecutor = Executors.newSingleThreadExecutor { r -> Thread(r, "PomagierBrainInit") }
    @Volatile private var statusText: String = "STARTING"
    @Volatile private var initError: String = ""
    private lateinit var brainDir: File

    fun initializeAsync(context: Context, onReady: (() -> Unit)? = null) {
        if (!started.compareAndSet(false, true)) {
            onReady?.invoke()
            return
        }
        val app = context.applicationContext
        brainDir = File(app.filesDir, "pomagier_brain").apply { mkdirs() }
        ensureConfig()

        initExecutor.execute {
            try {
                if (!Python.isStarted()) Python.start(AndroidPlatform(app))
                val raw = Python.getInstance().getModule("brain_android").callAttr("init", brainDir.absolutePath).toString()
                val obj = JSONObject(raw)
                if (obj.optBoolean("ok")) {
                    statusText = "OK"
                    initError = ""
                } else {
                    statusText = "ERROR"
                    initError = obj.optString("error", "Nieznany błąd Braina")
                }
            } catch (t: Throwable) {
                statusText = "ERROR"
                initError = "${t.javaClass.simpleName}: ${t.message ?: "błąd inicjalizacji"}"
            } finally {
                readyLatch.countDown()
                onReady?.invoke()
            }
        }
    }

    private fun awaitReady(seconds: Long = 20): Boolean {
        if (!started.get()) return false
        if (statusText != "STARTING") return statusText == "OK"
        return try {
            readyLatch.await(seconds, TimeUnit.SECONDS) && statusText == "OK"
        } catch (_: InterruptedException) {
            Thread.currentThread().interrupt(); false
        }
    }

    @Synchronized
    fun decide(payloadJson: String): String {
        if (!awaitReady()) {
            return JSONObject()
                .put("ok", false)
                .put("error", initError.ifBlank { "Brain jeszcze się uruchamia" })
                .toString()
        }
        return try {
            Python.getInstance().getModule("brain_android").callAttr("decide_json", payloadJson).toString()
        } catch (t: Throwable) {
            JSONObject().put("ok", false).put("error", "${t.javaClass.simpleName}: ${t.message}").toString()
        }
    }

    fun statusJson(): String {
        if (!started.get()) return JSONObject().put("ok", false).put("status", "STARTING").toString()
        if (statusText == "STARTING") return JSONObject().put("ok", false).put("status", "STARTING").toString()
        if (statusText == "ERROR") return JSONObject().put("ok", false).put("status", "ERROR").put("error", initError).toString()
        return try {
            Python.getInstance().getModule("brain_android").callAttr("status_json").toString()
        } catch (t: Throwable) {
            JSONObject().put("ok", false).put("status", "ERROR").put("error", t.message ?: "błąd").toString()
        }
    }

    fun memoryJson(): String {
        if (!awaitReady(3)) return JSONObject().put("ok", false).put("error", initError.ifBlank { "Brain nie jest gotowy" }).toString()
        return try {
            Python.getInstance().getModule("brain_android").callAttr("memory_json").toString()
        } catch (t: Throwable) {
            JSONObject().put("ok", false).put("error", t.message ?: "błąd").toString()
        }
    }

    fun shortStatus(): String {
        return try {
            val obj = JSONObject(statusJson())
            if (obj.optBoolean("ok")) {
                "Brain ${obj.optString("brainVersion", "3.2.8")} • ${obj.optString("status", "OK")} • decyzje ${obj.optInt("decisions", 0)}"
            } else {
                val status = obj.optString("status", statusText)
                if (status == "STARTING") "Brain 3.2.8 • uruchamianie…"
                else "Brain • $status • ${obj.optString("error", initError)}"
            }
        } catch (_: Throwable) {
            "Brain • $statusText${if (initError.isNotBlank()) " • $initError" else ""}"
        }
    }

    fun databaseFile(): File = File(brainDir, "pomagier_ai.db")
    fun logFile(): File = File(brainDir, "pomagier_ai.log")

    private fun ensureConfig() {
        val file = File(brainDir, "config.json")
        val obj = if (file.exists()) {
            try { JSONObject(file.readText(Charsets.UTF_8)) } catch (_: Throwable) { JSONObject() }
        } else JSONObject()

        obj.put("bind", "127.0.0.1")
        obj.put("port", 8765)
        obj.put("bridge_token", BRIDGE_TOKEN)

        val localLlm = obj.optJSONObject("local_llm") ?: JSONObject()
        localLlm.put("enabled", false)
        obj.put("local_llm", localLlm)

        val openAi = obj.optJSONObject("openai_advisor") ?: JSONObject()
        openAi.put("enabled", false)
        obj.put("openai_advisor", openAi)

        file.writeText(obj.toString(2), Charsets.UTF_8)
    }
}
