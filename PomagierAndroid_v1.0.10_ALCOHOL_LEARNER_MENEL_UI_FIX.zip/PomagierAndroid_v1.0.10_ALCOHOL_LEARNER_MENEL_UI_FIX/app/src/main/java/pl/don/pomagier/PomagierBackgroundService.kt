package pl.don.pomagier

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager

class PomagierBackgroundService : Service() {

    companion object {
        private const val CHANNEL_ID = "pomagier_background"
        private const val NOTIFICATION_ID = 10401
        private const val ACTION_START = "pl.don.pomagier.action.BACKGROUND_START"
        private const val ACTION_STOP = "pl.don.pomagier.action.BACKGROUND_STOP"
        private const val PREFS = "pomagier_android"
        private const val KEY_ACTIVE = "background_mode_active"

        fun isEnabled(context: Context): Boolean =
            context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean(KEY_ACTIVE, false)

        fun start(context: Context, force: Boolean = false): Boolean {
            val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            val alreadyRequested = prefs.getBoolean(KEY_ACTIVE, false)
            if (alreadyRequested && !force) return true

            prefs.edit().putBoolean(KEY_ACTIVE, true).apply()
            val intent = Intent(context, PomagierBackgroundService::class.java).setAction(ACTION_START)
            return runCatching {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) context.startForegroundService(intent)
                else context.startService(intent)
                true
            }.getOrElse {
                prefs.edit().putBoolean(KEY_ACTIVE, false).apply()
                false
            }
        }

        fun stop(context: Context) {
            context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putBoolean(KEY_ACTIVE, false).apply()
            context.stopService(Intent(context, PomagierBackgroundService::class.java))
        }
    }

    private val handler = Handler(Looper.getMainLooper())
    private var wakeLock: PowerManager.WakeLock? = null
    private var lastWebViewAlive: Boolean? = null

    private val heartbeat = object : Runnable {
        override fun run() {
            val alive = BackgroundRuntime.kick()
            if (lastWebViewAlive != alive) {
                lastWebViewAlive = alive
                updateNotification(alive)
            }
            handler.postDelayed(this, 5_000L)
        }
    }

    override fun onCreate() {
        super.onCreate()
        createChannel()
        acquireWakeLock()
        startForegroundCompat(buildNotification(BackgroundRuntime.hasActivity()))
        handler.post(heartbeat)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putBoolean(KEY_ACTIVE, false).apply()
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
            return START_NOT_STICKY
        }

        getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putBoolean(KEY_ACTIVE, true).apply()
        acquireWakeLock()
        startForegroundCompat(buildNotification(BackgroundRuntime.hasActivity()))
        return START_STICKY
    }

    override fun onTaskRemoved(rootIntent: Intent?) {
        // The service intentionally survives removing the task. If the Activity/WebView
        // disappears, the notification changes and tells the user to reopen the app.
        updateNotification(BackgroundRuntime.hasActivity())
        super.onTaskRemoved(rootIntent)
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        runCatching { wakeLock?.takeIf { it.isHeld }?.release() }
        wakeLock = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun acquireWakeLock() {
        if (wakeLock?.isHeld == true) return
        val pm = getSystemService(POWER_SERVICE) as PowerManager
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "PomagierByDon:Background").apply {
            setReferenceCounted(false)
            acquire()
        }
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val manager = getSystemService(NotificationManager::class.java)
        val channel = NotificationChannel(
            CHANNEL_ID,
            "Pomagier — praca w tle",
            NotificationManager.IMPORTANCE_LOW
        ).apply {
            description = "Podtrzymuje Pomagiera i lokalny Brain podczas pracy w tle"
            setShowBadge(false)
        }
        manager.createNotificationChannel(channel)
    }

    private fun startForegroundCompat(notification: Notification) {
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(
                NOTIFICATION_ID,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
            )
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    private fun updateNotification(webViewAlive: Boolean) {
        val manager = getSystemService(NotificationManager::class.java)
        manager.notify(NOTIFICATION_ID, buildNotification(webViewAlive))
    }

    private fun buildNotification(webViewAlive: Boolean): Notification {
        val openIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val openPending = PendingIntent.getActivity(
            this,
            0,
            openIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val stopIntent = Intent(this, PomagierBackgroundService::class.java).setAction(ACTION_STOP)
        val stopPending = PendingIntent.getService(
            this,
            1,
            stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val text = if (webViewAlive) {
            "Pomagier pracuje w tle • WebView + Brain są podtrzymywane"
        } else {
            "Usługa działa, ale ekran gry został zamknięty — otwórz aplikację, aby wznowić WebView"
        }

        val builder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Notification.Builder(this, CHANNEL_ID)
        } else {
            @Suppress("DEPRECATION") Notification.Builder(this)
        }

        return builder
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            .setContentTitle("Pomagier by Don — praca w tle")
            .setContentText(text)
            .setStyle(Notification.BigTextStyle().bigText(text))
            .setContentIntent(openPending)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setCategory(Notification.CATEGORY_SERVICE)
            .addAction(Notification.Action.Builder(R.drawable.ic_launcher_foreground, "STOP", stopPending).build())
            .build()
    }
}
