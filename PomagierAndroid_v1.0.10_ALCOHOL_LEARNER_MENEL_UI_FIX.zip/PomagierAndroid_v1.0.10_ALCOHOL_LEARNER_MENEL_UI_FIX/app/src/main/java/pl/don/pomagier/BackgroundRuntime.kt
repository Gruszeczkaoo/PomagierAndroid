package pl.don.pomagier

import java.lang.ref.WeakReference

/**
 * In-process link between the foreground service and the Activity-owned WebView.
 * The weak reference avoids leaking the Activity when Android recreates it.
 */
object BackgroundRuntime {
    @Volatile private var activityRef: WeakReference<MainActivity>? = null

    fun attach(activity: MainActivity) {
        activityRef = WeakReference(activity)
    }

    fun detach(activity: MainActivity) {
        if (activityRef?.get() === activity) activityRef = null
    }

    fun hasActivity(): Boolean = activityRef?.get() != null

    fun kick(): Boolean {
        val activity = activityRef?.get() ?: return false
        activity.runOnUiThread { activity.backgroundHeartbeat() }
        return true
    }
}
