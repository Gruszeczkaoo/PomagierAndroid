package pl.don.pomagier

import android.content.ContentValues
import android.content.Context
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.webkit.JavascriptInterface
import android.widget.Toast
import org.json.JSONObject
import java.io.File

class AndroidBridge(private val context: Context) {
    private val mainHandler = Handler(Looper.getMainLooper())

    @JavascriptInterface
    fun saveTextFile(fileName: String, content: String) {
        val safeName = sanitizeFileName(fileName)
        val mime = when {
            safeName.endsWith(".csv", ignoreCase = true) -> "text/csv"
            safeName.endsWith(".json", ignoreCase = true) -> "application/json"
            else -> "text/plain"
        }
        saveBytes(safeName, mime, content.toByteArray(Charsets.UTF_8))
    }

    @JavascriptInterface fun appVersion(): String = BuildConfig.VERSION_NAME
    @JavascriptInterface fun isAndroidApp(): Boolean = true
    @JavascriptInterface fun brainDecide(payloadJson: String): String = BrainManager.decide(payloadJson)
    @JavascriptInterface fun brainStatus(): String = BrainManager.statusJson()
    @JavascriptInterface fun brainMemory(): String = BrainManager.memoryJson()

    @JavascriptInterface
    fun setAutomationActive(active: Boolean) {
        val activity = context as? MainActivity
        if (activity != null) {
            activity.setAutomationBackgroundActive(active)
        } else {
            if (active) PomagierBackgroundService.start(context) else PomagierBackgroundService.stop(context)
        }
    }

    @JavascriptInterface
    fun backgroundStatus(): String = JSONObject()
        .put("ok", true)
        .put("active", PomagierBackgroundService.isEnabled(context))
        .put("webViewAlive", BackgroundRuntime.hasActivity())
        .toString()

    @JavascriptInterface
    fun appInfo(): String = JSONObject()
        .put("ok", true)
        .put("app", "Pomagier by Don")
        .put("version", BuildConfig.VERSION_NAME)
        .put("brain", BrainManager.shortStatus())
        .toString()

    fun exportBrainDatabase() {
        val db = BrainManager.databaseFile()
        if (!db.exists()) {
            toast("Brain nie ma jeszcze bazy danych.")
            return
        }
        try {
            saveBytes("pomagier_ai_android.db", "application/octet-stream", db.readBytes())
        } catch (t: Throwable) {
            toast("Błąd eksportu bazy: ${t.message}")
        }
    }

    fun exportBrainLog() {
        val log = BrainManager.logFile()
        if (!log.exists()) {
            toast("Brak logu Braina.")
            return
        }
        try {
            saveBytes("pomagier_ai_android.log", "text/plain", log.readBytes())
        } catch (t: Throwable) {
            toast("Błąd eksportu logu: ${t.message}")
        }
    }

    private fun saveBytes(fileName: String, mime: String, bytes: ByteArray) {
        try {
            val values = ContentValues().apply {
                put(MediaStore.Downloads.DISPLAY_NAME, fileName)
                put(MediaStore.Downloads.MIME_TYPE, mime)
                put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/PomagierByDon")
                put(MediaStore.Downloads.IS_PENDING, 1)
            }
            val resolver = context.contentResolver
            val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                ?: throw IllegalStateException("Nie udało się utworzyć pliku")
            resolver.openOutputStream(uri, "w")?.use { it.write(bytes) }
                ?: throw IllegalStateException("Nie udało się otworzyć pliku")
            values.clear()
            values.put(MediaStore.Downloads.IS_PENDING, 0)
            resolver.update(uri, values, null, null)
            toast("Zapisano: Pobrane/PomagierByDon/$fileName")
        } catch (t: Throwable) {
            toast("Błąd zapisu: ${t.message}")
        }
    }

    private fun toast(message: String) {
        mainHandler.post { Toast.makeText(context, message, Toast.LENGTH_LONG).show() }
    }

    private fun sanitizeFileName(input: String): String {
        val cleaned = input
            .replace(Regex("[\\\\/:*?\"<>|]"), "_")
            .replace(Regex("\\s+"), "_")
            .take(160)
            .ifBlank { "pomagier_export.json" }
        return when {
            cleaned.endsWith(".json", true) || cleaned.endsWith(".csv", true) || cleaned.endsWith(".txt", true) || cleaned.endsWith(".log", true) || cleaned.endsWith(".db", true) -> cleaned
            else -> "$cleaned.txt"
        }
    }
}
