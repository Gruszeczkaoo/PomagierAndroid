# Pomagier by Don — Android v1.0.10

Pełna aplikacja Android dla Menelgame z wbudowanym **Pomagierem 8.8.17** i lokalnym **Pomagier AI Brain 3.2.8**.

## Co działa

- Menelgame działa wewnątrz WebView; logowanie i cookies zostają w aplikacji.
- Pomagier 8.8.17 jest wstrzykiwany automatycznie przy starcie dokumentu — bez Tampermonkey.
- Brain 3.2.8 działa lokalnie w APK przez Chaquopy (JS → Kotlin → Python), bez komputera i bez localhost HTTP.
- SQLite Braina jest trwały w pamięci aplikacji.
- Eksporty JSON/CSV zapisują się do `Pobrane/PomagierByDon/`.
- Długie przytrzymanie 🧠 eksportuje bazę Braina.
- Menu ⋮ umożliwia eksport DB/logu, czyszczenie cache, reset danych gry i przejście do ustawień aplikacji/baterii.
- Tryb nocny utrzymuje WebView aktywny, ustawia jasność na 1%, pokazuje czarną kurtynę i blokuje przypadkowe dotknięcia.
- Automatyczny recovery po awarii procesu WebView.
- Obsługa błędu połączenia z przyciskiem ponowienia.
- Debugowanie WebView jest włączone tylko w buildzie debug.

## Wersje

- Android app: **1.0.10**
- Pomagier userscript: **8.8.17**
- Brain: **3.2.8**
- minSdk: 29 (Android 10+)
- targetSdk/compileSdk: 35
- ABI: arm64-v8a + x86_64

## Budowanie APK

### GitHub Actions
Po wrzuceniu całego projektu do repozytorium GitHub workflow `.github/workflows/build-apk.yml` buduje podpisany `Pomagier-by-Don-v1.0.10.apk` i plik SHA-256. W GitHub: **Actions → Build Pomagier Android APK → Run workflow** albo zwykły push do `main`. Projekt zawiera prywatny klucz podpisu przeznaczony wyłącznie do osobistych buildów sideload, dzięki czemu kolejne wersje mogą aktualizować aplikację bez utraty danych.

### Android Studio
1. Otwórz katalog projektu.
2. Poczekaj na Gradle Sync.
3. `Build → Build Bundle(s) / APK(s) → Build APK(s)`.
4. APK release: `app/build/outputs/apk/release/app-release.apk`.

## Tryb nocny i praca w tle
Tryb nocny nadal utrzymuje ekran praktycznie czarny i aktywny. Od v1.0.4 po uruchomieniu Pomagiera aplikacja automatycznie startuje **Foreground Service** z trwałym powiadomieniem, trzyma częściowy WakeLock i co 5 sekund wykonuje natywny heartbeat do scheduler-a Pomagiera w WebView. `WebView.onPause()` nie jest wywoływane, gdy tryb tła jest aktywny, a renderer WebView ma priorytet IMPORTANT. W menu ⋮ można ręcznie włączyć/wyłączyć pracę w tle i poprosić Androida o wyłączenie optymalizacji baterii dla aplikacji.

To znacznie zwiększa niezawodność po naciśnięciu HOME i po zgaszeniu ekranu, ale nie daje absolutnej gwarancji na każdym telefonie/OEM. **Nie usuwaj aplikacji z listy ostatnich aplikacji podczas pracy Pomagiera** — Foreground Service może przeżyć, ale ekran WebView może zostać zniszczony; powiadomienie wtedy poprosi o ponowne otwarcie aplikacji.

## Bezpieczeństwo

- HTTP cleartext jest wyłączony.
- Linki poza `menelgame.online` otwierają się w zewnętrznej przeglądarce.
- Dostęp do plików lokalnych z WebView jest wyłączony.
- Backup systemowy aplikacji jest wyłączony, aby nie kopiować cookies/logowania.
- Brain nie otrzymuje cookies ani tokenu logowania z Menelgame; dostaje tylko payload decyzyjny z userscriptu.

## Podpis APK

Projekt zawiera `app/pomagier-local.jks`, używany wyłącznie do osobistych instalacji poza Google Play. Nie publikuj tego klucza w publicznym repozytorium. Zachowaj go, bo kolejne APK muszą używać tego samego podpisu, aby Android pozwolił zaktualizować aplikację bez odinstalowania i utraty danych.


## v1.0.2 — Session Fix
- Android/WebView: sesja API może zostać odtworzona w RAM z aktualnego `menelgame_user.token`, bez czekania na przechwycenie requestu Bazaru/Warsztatu.
- Token nie jest zapisywany do logów, eksportów ani bazy Braina.
- Fallback działa również, gdy logowanie zakończy się wewnątrz SPA bez pełnego przeładowania strony.


## v1.0.2 — Android UI fix
- ruchomy panel Pomagiera palcem (Pointer Events)
- zmiana rozmiaru panelu palcem
- przycisk minimalizacji dostępny w mobilnym nagłówku
- sensowny domyślny rozmiar panelu zamiast wymuszonego full-screen
- natywny przycisk P nie resetuje już geometrii panelu
- górny pasek systemowy Androida (godzina/bateria/Wi‑Fi) jest ukryty w normalnym trybie aplikacji
- w tej historycznej wersji dolna nawigacja Androida pozostawała dostępna; od v1.0.7 działa immersive


## v1.0.3 — Mobile UI / Responsive Fix
- poprawiona responsywność panelu Pomagiera na telefonie
- naprawiona specyficzność reguł CSS: mobilne układy faktycznie nadpisują desktopowe siatki
- karty w zakładce Sesje układają się 2×N zamiast ściskać 5–6 kolumn obok siebie
- nieparzysta ostatnia karta sesji zajmuje całą szerokość wiersza
- wartości i opisy kart mogą się normalnie zawijać zamiast kończyć wielokropkiem
- toolbar i przyciski lepiej dopasowane do wąskiego panelu
- tabele pozostają przewijane poziomo, bez rozbijania całego panelu
- poprawione odstępy, nagłówki i przewijanie zakładek w trybie mobilnym
- zachowane poprawki sesji, ruchomy/minimalizowany panel i ukrywanie status bara z v1.0.2


## v1.0.5 — Auto Account ID

- Automatyczne pobieranie `menelgame_user.character.id` po zalogowaniu.
- Pole ID w ustawieniach jest tylko do odczytu i pokazuje wykryte konto.
- Aktualizacja z wcześniejszej wersji automatycznie zastępuje błędne/domyślne ID 462.
- Przy zmianie konta w tej samej aplikacji odświeżany jest wzorzec sesji i czyszczone są dane robocze zależne od poprzedniej postaci.
- Snapshot zapisuje źródło ID i nick wykrytej postaci.

## v1.0.4 — Background Mode
- Foreground Service `specialUse` uruchamiany automatycznie razem z trybem autonomicznym Pomagiera.
- Stałe powiadomienie Androida „Pomagier by Don — praca w tle”.
- `PARTIAL_WAKE_LOCK` podtrzymuje CPU przy zgaszonym ekranie.
- Natywny heartbeat co 5 s wywołuje dokładnie ten sam scheduler Pomagiera, nawet gdy timery WebView są ograniczane w tle.
- WebView nie jest pauzowany przez `onPause`, kiedy tryb tła jest aktywny.
- Renderer WebView ma priorytet `RENDERER_PRIORITY_IMPORTANT`, a `offscreenPreRaster` jest włączony.
- START Pomagiera automatycznie włącza usługę tła; STOP automatycznie ją wyłącza.
- Recovery pozostawia usługę aktywną podczas prób samonaprawy.
- Menu ⋮ pokazuje stan pracy w tle i pozwala przełączyć ją ręcznie.
- Dodany skrót do wyłączenia optymalizacji baterii dla Pomagiera.
- Przycisk Wstecz przy aktywnym tle przenosi aplikację do tła zamiast niszczyć Activity/WebView.
- Po ubiciu/zamknięciu Activity usługa zmienia treść powiadomienia i prosi o ponowne otwarcie aplikacji.
- Zachowane wszystkie poprawki v1.0.1–v1.0.3.


## v1.0.7 — Bubble + immersive + Alkohol
- Minimalizacja Pomagiera do przeciąganego bąbelka „by DonDżon”.
- Kliknięcie bąbelka przywraca pełny panel.
- Osobna zakładka „🍶 Alkohol”.
- Dolna nawigacja Androida jest ukryta w trybie immersive i pojawia się przejściowo po przesunięciu od dołu.
- Zachowane poprawki MenelMode 8.8.12 i automat alkoholu 8.8.13.


## v1.0.8 — Alkohol V2 + Menel dedupe

- Alkohol V2 uczy pełną sekwencję Odbierz → Użyj → x1/x2 → dokup → Wytwarzaj; stare profile v1 wymagają jednorazowego ponownego nauczenia.
- MenelMode zachowuje stan clear-result przez resync, nie wysyła wielokrotnie tego samego wyniku do Brain i obsługuje HTTP 5xx jako niejednoznaczny zapis z ponowną weryfikacją GET.
- Brain 3.2.8 jednorazowo czyści skażone action_stats MenelMode, pozostawiając prawidłowe menel_stats.
- Snapshot zawiera bezpieczną diagnostykę Alcohol Auto bez nagłówków autoryzacji i pełnych body requestów.


## v1.0.9 — Menel UI Summary Fix
- Przy gotowym MenelMode automat najpierw klika prawdziwy przycisk gry **Podsumuj** i dopiero po świeżym GET uznaje wynik za zamknięty.
- Jeśli nie ma jeszcze nauczonej sekwencji zamknięcia, klik UI automatycznie przechwytuje requesty gry i może zapisać bezpieczny replay.
- Bezpośredni `/clear-result` pozostaje fallbackiem, gdy przycisk UI nie jest dostępny.


## v1.0.10 — Alcohol Learner Quantity Fix

- Naprawia uczenie destylacji, które mogło utknąć na komunikacie `klik QUANTITY — czekam na request gry`.
- `Wytwarzaj x2` jest teraz rozpoznawane jako START, a nie jako QUANTITY.
- Wybór x1/x2 jest krokiem opcjonalnym: jeśli UI nie wysyła osobnego requestu, uczenie nie blokuje się; ilość zostaje zawarta w requestcie startowym gry.
- Zachowuje Menel UI Summary Fix z v1.0.9 oraz Alcohol V2/Menel dedupe z v1.0.8.
