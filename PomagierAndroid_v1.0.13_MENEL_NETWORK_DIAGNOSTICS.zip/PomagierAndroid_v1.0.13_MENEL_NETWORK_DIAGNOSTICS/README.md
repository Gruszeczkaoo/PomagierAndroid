# Pomagier by Don v1.0.13 — MENEL NETWORK DIAGNOSTICS

Android 1.0.13 • userscript 8.8.20 • Brain 3.2.8

## Co dodano

- diagnostykę MenelMode + przejazdów między dzielnicami działającą bez PC i bez DevTools,
- rejestr kliknięć w UI gry,
- rejestr request/response dla endpointów scavenging / travel / district / character,
- przy każdym istotnym zdarzeniu zapis stanu: aktualna dzielnica, podróż, pendingActivityResult, pendingCompletion, menelStatus, worldActionGate, menelClearSync, districtSweep, actionGuard i następna decyzja Braina,
- state_change + heartbeat co 30 s, żeby było widać gdzie automat/stany się zatrzymują,
- podczas diagnostyki automatyczne akcje MenelMode i podróży Pomagiera są wstrzymane, aby zebrać czysty ręczny wzorzec gry,
- eksport `pomagier_menel_network_trace_*.json` do Pobrane/PomagierByDon,
- snapshot Pomagiera zawiera teraz skróconą sekcję `menelNetworkDiag`.

## Jak nagrać test

1. Wejdź w Pomagier -> zakładka **Pomagier**.
2. W sekcji **Diagnostyka MenelMode + dzielnice — Android** kliknij **Rozpocznij diagnostykę MenelMode**.
3. MenelMode i przejazdy wykonuj ręcznie w grze. Najlepszy test to pełny ciąg:
   - jeśli MenelMode jest gotowy: **Podsumuj**,
   - wybierz niezrobioną dzielnicę i rozpocznij podróż,
   - zakończ podróż,
   - uruchom MenelMode,
   - po zakończeniu kliknij **Podsumuj**,
   - rozpocznij podróż do następnej niezrobionej dzielnicy.
4. Gdy masz przynajmniej jeden pełny cykl, wróć do Pomagiera i kliknij **Zakończ i eksportuj JSON**.
5. Wyślij plik `pomagier_menel_network_trace_*.json` do analizy.

## Prywatność diagnostyki

Eksport nie zapisuje nagłówków HTTP, cookies ani Authorization. Pola o nazwach token/auth/password/secret/session są maskowane.

## Zachowane funkcje

Wersja bazuje na v1.0.12 / 8.8.19, więc zachowuje Alcohol DIRECT API, dotychczasowe poprawki MenelMode, PvP Lab, Boss Lab, Brain 3.2.8 i pozostałą automatykę.
