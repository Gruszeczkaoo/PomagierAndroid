# Pomagier by Don v1.0.15 — ALCOHOL SCHEDULER FIX

Android 1.0.15 • userscript 8.8.22 • Brain 3.2.9

Ta wersja naprawia błąd automatycznego odbioru i ponownego startu produkcji alkoholu w Alcohol DIRECT API.

Najważniejsze poprawki:
- scheduler alkoholu nie sprawdza już starego `alcoholProfileSelected()` przed uruchomieniem automatu
- wybrana receptura z Notesu (`alcoholRecipeId`) jest jedynym źródłem receptury dla DIRECT API
- gdy nadejdzie `nextAt`, scheduler bezpośrednio uruchamia `alcoholAutoCycle({force:false})`
- po odebraniu gotowego alkoholu `lastSessionStatus` przechodzi na `idle`
- po udanym uruchomieniu nowej destylacji `lastSessionStatus` przechodzi na `processing`
- ręczny przycisk „Sprawdź/start teraz” i automat używają teraz tej samej ścieżki DIRECT API

Poprawka wynika z diagnostyki z 21.09.2026: automat był włączony, receptura Notes była wybrana,
ale `legacyProfiles` było puste. Stary warunek schedulera wymagał legacy profilu i blokował samoczynny start.

Wersja zachowuje:
- MenelMode COMPLETE -> CLEAR z v1.0.14
- Brain 3.2.9 i poprawki SWEEP
- diagnostykę MenelMode
- Alcohol DIRECT API, Notes, x1/x2 i automatyczny dokup brakujących składników
