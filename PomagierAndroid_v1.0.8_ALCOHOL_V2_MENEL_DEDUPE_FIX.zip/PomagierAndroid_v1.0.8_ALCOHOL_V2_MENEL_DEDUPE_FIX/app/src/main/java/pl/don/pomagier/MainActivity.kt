package pl.don.pomagier

import android.annotation.SuppressLint
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.view.View
import android.view.WindowInsets
import android.view.WindowInsetsController
import android.view.WindowManager
import android.webkit.CookieManager
import android.webkit.RenderProcessGoneDetail
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.webkit.WebViewCompat
import androidx.webkit.WebViewFeature

class MainActivity : Activity() {

    companion object {
        private const val GAME_URL = "https://menelgame.online/"
        private const val GAME_HOST = "menelgame.online"
        private const val PREFS = "pomagier_android"
    }

    private lateinit var webView: WebView
    private lateinit var progressBar: ProgressBar
    private lateinit var titleText: TextView
    private lateinit var statusText: TextView
    private lateinit var errorOverlay: View
    private lateinit var errorText: TextView
    private lateinit var nightCurtain: View
    private lateinit var nightStatusText: TextView
    private lateinit var bridge: AndroidBridge
    private var userscript: String = ""
    private var pageReady = false
    private var nightMode = false

    @SuppressLint("SetJavaScriptEnabled", "AddJavascriptInterface")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        BackgroundRuntime.attach(this)
        window.decorView.post { applyNormalSystemBars() }

        webView = findViewById(R.id.webView)
        progressBar = findViewById(R.id.progressBar)
        titleText = findViewById(R.id.titleText)
        statusText = findViewById(R.id.statusText)
        errorOverlay = findViewById(R.id.errorOverlay)
        errorText = findViewById(R.id.errorText)
        nightCurtain = findViewById(R.id.nightCurtain)
        nightStatusText = findViewById(R.id.nightStatusText)
        bridge = AndroidBridge(this)
        userscript = assets.open("pomagier.user.js").bufferedReader().use { it.readText() }

        BrainManager.initializeAsync(applicationContext) {
            runOnUiThread { updateNativeStatus() }
        }

        configureWebView()
        configureButtons()
        installDocumentStartUserscript()

        if (PomagierBackgroundService.isEnabled(this)) {
            PomagierBackgroundService.start(this, force = true)
        }

        if (savedInstanceState == null) webView.loadUrl(GAME_URL) else webView.restoreState(savedInstanceState)
        updateNativeStatus()
    }

    @SuppressLint("SetJavaScriptEnabled", "AddJavascriptInterface")
    private fun configureWebView() {
        WebView.setWebContentsDebuggingEnabled(BuildConfig.DEBUG)
        webView.setBackgroundColor(getColor(R.color.bg))
        webView.overScrollMode = View.OVER_SCROLL_NEVER
        webView.setRendererPriorityPolicy(WebView.RENDERER_PRIORITY_IMPORTANT, false)
        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            loadsImagesAutomatically = true
            useWideViewPort = true
            loadWithOverviewMode = false
            builtInZoomControls = false
            displayZoomControls = false
            setSupportZoom(false)
            allowFileAccess = false
            allowContentAccess = false
            javaScriptCanOpenWindowsAutomatically = false
            setSupportMultipleWindows(false)
            mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
            mediaPlaybackRequiresUserGesture = true
            textZoom = 100
            cacheMode = WebSettings.LOAD_DEFAULT
            offscreenPreRaster = true
            userAgentString = "$userAgentString PomagierAndroid/${BuildConfig.VERSION_NAME}"
        }

        CookieManager.getInstance().apply {
            setAcceptCookie(true)
            setAcceptThirdPartyCookies(webView, true)
        }

        // Most JS runs only on menelgame.online. The Brain itself also requires a private bridge token.
        webView.addJavascriptInterface(bridge, "AndroidBridge")

        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val uri = request.url
                return if (isGameUri(uri)) false else {
                    openExternal(uri); true
                }
            }

            override fun onPageStarted(view: WebView, url: String?, favicon: Bitmap?) {
                super.onPageStarted(view, url, favicon)
                pageReady = false
                errorOverlay.visibility = View.GONE
                progressBar.visibility = View.VISIBLE
                statusText.text = "Ładowanie gry…"
                if (!WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT) && isGameUrl(url)) {
                    runCatching { view.evaluateJavascript(userscript, null) }
                }
            }

            override fun onPageFinished(view: WebView, url: String?) {
                super.onPageFinished(view, url)
                progressBar.visibility = View.GONE
                pageReady = isGameUrl(url)
                if (!WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT) && pageReady) {
                    runCatching { view.evaluateJavascript(userscript, null) }
                }
                updateNativeStatus()
                if (pageReady) verifyPomagierLoaded()
            }

            override fun onReceivedError(view: WebView, request: WebResourceRequest, error: WebResourceError) {
                super.onReceivedError(view, request, error)
                if (request.isForMainFrame) showLoadError(error.description?.toString() ?: "Błąd połączenia")
            }

            override fun onRenderProcessGone(view: WebView, detail: RenderProcessGoneDetail): Boolean {
                Toast.makeText(this@MainActivity, "WebView został zrestartowany — wczytuję grę ponownie.", Toast.LENGTH_LONG).show()
                runCatching { view.destroy() }
                recreate()
                return true
            }
        }

        webView.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView?, newProgress: Int) {
                progressBar.progress = newProgress
                progressBar.visibility = if (newProgress in 0..99) View.VISIBLE else View.GONE
            }
            override fun onReceivedTitle(view: WebView?, title: String?) {
                if (!title.isNullOrBlank() && pageReady) titleText.text = "Pomagier by Don"
            }
        }
    }

    private fun configureButtons() {
        findViewById<Button>(R.id.backButton).setOnClickListener {
            if (webView.canGoBack()) webView.goBack()
            else if (PomagierBackgroundService.isEnabled(this)) moveTaskToBack(true)
            else finish()
        }
        findViewById<Button>(R.id.reloadButton).apply {
            setOnClickListener { webView.reload() }
            setOnLongClickListener {
                webView.clearCache(true)
                webView.reload()
                Toast.makeText(this@MainActivity, "Cache WebView wyczyszczony.", Toast.LENGTH_SHORT).show()
                true
            }
        }
        findViewById<Button>(R.id.brainButton).apply {
            setOnClickListener { showBrainStatus() }
            setOnLongClickListener { bridge.exportBrainDatabase(); true }
        }
        findViewById<Button>(R.id.nightButton).setOnClickListener { enterNightMode() }
        findViewById<Button>(R.id.pomagierButton).setOnClickListener { openPomagierPanel() }
        findViewById<Button>(R.id.moreButton).setOnClickListener { showToolsDialog() }
        findViewById<Button>(R.id.retryButton).setOnClickListener {
            errorOverlay.visibility = View.GONE
            webView.loadUrl(GAME_URL)
        }
        findViewById<Button>(R.id.exitNightButton).setOnClickListener { exitNightMode() }
    }

    private fun installDocumentStartUserscript() {
        if (WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT)) {
            WebViewCompat.addDocumentStartJavaScript(webView, userscript, setOf("https://menelgame.online"))
        }
    }

    private fun verifyPomagierLoaded() {
        webView.postDelayed({
            if (!pageReady) return@postDelayed
            webView.evaluateJavascript("Boolean(document.getElementById('mg-mega-premium'))") { result ->
                statusText.text = when (result) {
                    "true" -> "Pomagier 8.8.15 • ${BrainManager.shortStatus()}"
                    else -> "Gra działa • Pomagier jeszcze się inicjalizuje…"
                }
            }
        }, 1200)
        webView.postDelayed({ updateNativeStatus() }, 4000)
    }

    private fun openPomagierPanel() {
        if (!pageReady) {
            Toast.makeText(this, "Najpierw musi załadować się Menelgame.", Toast.LENGTH_SHORT).show()
            return
        }
        val js = """
            (() => {
              const p = document.getElementById('mg-mega-premium');
              if (!p) return 'missing';
              if (p.style.display === 'none') {
                p.style.display='block';
                return 'shown';
              }
              const min = p.querySelector('button[data-act="min"]');
              if (min) { min.click(); return 'toggled'; }
              p.style.display='block';
              return 'shown';
            })();
        """.trimIndent()
        webView.evaluateJavascript(js) { result ->
            if (result == "\"missing\"") Toast.makeText(this, "Pomagier jeszcze się ładuje — odśwież stronę, jeśli nie pojawi się po chwili.", Toast.LENGTH_LONG).show()
        }
    }

    private fun showBrainStatus() {
        AlertDialog.Builder(this)
            .setTitle("Pomagier AI Brain")
            .setMessage(BrainManager.shortStatus())
            .setPositiveButton("OK", null)
            .setNeutralButton("Eksport DB") { _, _ -> bridge.exportBrainDatabase() }
            .setNegativeButton("Eksport logu") { _, _ -> bridge.exportBrainLog() }
            .show()
    }

    private fun showToolsDialog() {
        val bgOn = PomagierBackgroundService.isEnabled(this)
        val items = arrayOf(
            "⌂ Strona główna gry",
            "🧠 Status Braina",
            "💾 Eksport bazy Braina",
            "📄 Eksport logu Braina",
            if (bgOn) "🟢 Praca w tle: WŁĄCZONA" else "⚪ Praca w tle: WYŁĄCZONA",
            "🔋 Wyłącz optymalizację baterii",
            "⚙ Ustawienia aplikacji",
            "🧹 Wyczyść cache WebView",
            "⚠ Reset logowania i danych gry",
            "ℹ Informacje o aplikacji"
        )
        AlertDialog.Builder(this)
            .setTitle("Pomagier by Don")
            .setItems(items) { _, which ->
                when (which) {
                    0 -> webView.loadUrl(GAME_URL)
                    1 -> showBrainStatus()
                    2 -> bridge.exportBrainDatabase()
                    3 -> bridge.exportBrainLog()
                    4 -> setAutomationBackgroundActive(!bgOn, fromUser = true)
                    5 -> requestBatteryOptimizationExemption()
                    6 -> openAppSettings()
                    7 -> { webView.clearCache(true); Toast.makeText(this, "Cache wyczyszczony.", Toast.LENGTH_SHORT).show() }
                    8 -> confirmResetWebData()
                    9 -> AlertDialog.Builder(this).setTitle("Pomagier by Don")
                        .setMessage("Android ${BuildConfig.VERSION_NAME}\nPomagier JS 8.8.15\nBrain 3.2.8\n\nGra + Pomagier + lokalny Brain + tryb pracy w tle.")
                        .setPositiveButton("OK", null).show()
                }
            }
            .show()
    }

    private fun confirmResetWebData() {
        AlertDialog.Builder(this)
            .setTitle("Wyczyścić dane gry?")
            .setMessage("To wyloguje z Menelgame i usunie localStorage Pomagiera/PvP/Boss Lab z tej aplikacji. Bazy Braina nie usuwa.")
            .setNegativeButton("Anuluj", null)
            .setPositiveButton("Wyczyść") { _, _ ->
                CookieManager.getInstance().removeAllCookies(null)
                CookieManager.getInstance().flush()
                webView.evaluateJavascript("localStorage.clear(); sessionStorage.clear();", null)
                webView.clearCache(true)
                webView.loadUrl(GAME_URL)
            }
            .show()
    }

    fun setAutomationBackgroundActive(active: Boolean, fromUser: Boolean = false) {
        runOnUiThread {
            if (active) {
                requestNotificationPermissionIfNeeded()
                val started = PomagierBackgroundService.start(this)
                if (started) {
                    webView.onResume()
                    webView.resumeTimers()
                    backgroundHeartbeat()
                    if (fromUser) Toast.makeText(this, "Praca w tle WŁĄCZONA.", Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(this, "Android nie pozwolił uruchomić pracy w tle. Otwórz aplikację i spróbuj ponownie.", Toast.LENGTH_LONG).show()
                }
            } else {
                PomagierBackgroundService.stop(this)
                if (fromUser) Toast.makeText(this, "Praca w tle WYŁĄCZONA.", Toast.LENGTH_SHORT).show()
            }
            updateNativeStatus()
        }
    }

    private fun requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(android.Manifest.permission.POST_NOTIFICATIONS), 104)
        }
    }

    private fun requestBatteryOptimizationExemption() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) return
        val pm = getSystemService(PowerManager::class.java)
        if (pm.isIgnoringBatteryOptimizations(packageName)) {
            Toast.makeText(this, "Pomagier ma już wyłączoną optymalizację baterii.", Toast.LENGTH_LONG).show()
            return
        }
        val direct = Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName"))
        runCatching { startActivity(direct) }.onFailure {
            runCatching { startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)) }
                .onFailure { openAppSettings() }
        }
    }

    private fun openAppSettings() {
        val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName"))
        runCatching { startActivity(intent) }.onFailure { startActivity(Intent(Settings.ACTION_SETTINGS)) }
    }

    fun backgroundHeartbeat() {
        if (!::webView.isInitialized || !pageReady || !PomagierBackgroundService.isEnabled(this)) return
        runCatching {
            webView.onResume()
            webView.resumeTimers()
            val js = """
                (() => {
                  try {
                    if (typeof window.__POMAGIER_ANDROID_BACKGROUND_TICK__ === 'function') {
                      return String(window.__POMAGIER_ANDROID_BACKGROUND_TICK__());
                    }
                    window.dispatchEvent(new Event('online'));
                    return 'hook-missing';
                  } catch (e) {
                    return 'error:' + String(e && e.message || e);
                  }
                })();
            """.trimIndent()
            webView.evaluateJavascript(js, null)
        }
    }

    private fun enterNightMode() {
        if (nightMode) return
        nightMode = true
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        window.attributes = window.attributes.apply { screenBrightness = 0.01f }
        nightCurtain.visibility = View.VISIBLE
        nightStatusText.text = "Pomagier pracuje • ${BrainManager.shortStatus()}"
        hideSystemBars()
    }

    private fun exitNightMode() {
        if (!nightMode) return
        nightMode = false
        window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        window.attributes = window.attributes.apply { screenBrightness = WindowManager.LayoutParams.BRIGHTNESS_OVERRIDE_NONE }
        nightCurtain.visibility = View.GONE
        applyNormalSystemBars()
        updateNativeStatus()
    }

    private fun hideSystemBars() {
        if (android.os.Build.VERSION.SDK_INT >= 30) {
            window.insetsController?.let { c ->
                c.hide(WindowInsets.Type.statusBars() or WindowInsets.Type.navigationBars())
                c.systemBarsBehavior = WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            }
        } else {
            @Suppress("DEPRECATION")
            window.decorView.systemUiVisibility = (
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or
                    View.SYSTEM_UI_FLAG_FULLSCREEN or
                    View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                )
        }
    }

    private fun applyNormalSystemBars() {
        // v1.0.7: pełny immersive również podczas zwykłej gry.
        // Dolne przyciski/gestowy pasek Androida są schowane i pokazują się
        // przejściowo dopiero po przesunięciu od krawędzi ekranu.
        hideSystemBars()
    }

    private fun updateNativeStatus() {
        titleText.text = "Pomagier by Don ${BuildConfig.VERSION_NAME}"
        val base = if (pageReady) "Gra online" else "Ładowanie"
        val bg = if (PomagierBackgroundService.isEnabled(this)) " • TŁO ON" else ""
        statusText.text = "$base • ${BrainManager.shortStatus()}$bg"
        if (nightMode) nightStatusText.text = "Pomagier pracuje • ${BrainManager.shortStatus()}"
    }

    private fun showLoadError(message: String) {
        progressBar.visibility = View.GONE
        errorText.text = "$message\n\nSprawdź połączenie z internetem i spróbuj ponownie."
        errorOverlay.visibility = View.VISIBLE
        statusText.text = "Błąd połączenia"
    }

    private fun openExternal(uri: Uri) {
        runCatching { startActivity(Intent(Intent.ACTION_VIEW, uri)) }
            .onFailure { Toast.makeText(this, "Nie można otworzyć linku.", Toast.LENGTH_SHORT).show() }
    }

    private fun isGameUri(uri: Uri): Boolean {
        val host = uri.host ?: return false
        return uri.scheme == "https" && (host == GAME_HOST || host.endsWith(".$GAME_HOST"))
    }
    private fun isGameUrl(url: String?): Boolean = !url.isNullOrBlank() && runCatching { isGameUri(Uri.parse(url)) }.getOrDefault(false)

    override fun onSaveInstanceState(outState: Bundle) {
        webView.saveState(outState)
        super.onSaveInstanceState(outState)
    }

    override fun onPause() {
        CookieManager.getInstance().flush()
        if (!nightMode && !PomagierBackgroundService.isEnabled(this)) {
            webView.onPause()
        } else {
            webView.onResume()
            webView.resumeTimers()
        }
        super.onPause()
    }

    override fun onResume() {
        super.onResume()
        webView.onResume()
        webView.resumeTimers()
        if (nightMode) hideSystemBars() else applyNormalSystemBars()
        if (PomagierBackgroundService.isEnabled(this)) backgroundHeartbeat()
        updateNativeStatus()
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) {
            if (nightMode) hideSystemBars() else applyNormalSystemBars()
        }
    }

    override fun onDestroy() {
        BackgroundRuntime.detach(this)
        if (::webView.isInitialized) runCatching { webView.destroy() }
        super.onDestroy()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        when {
            nightMode -> exitNightMode()
            errorOverlay.visibility == View.VISIBLE -> errorOverlay.visibility = View.GONE
            webView.canGoBack() -> webView.goBack()
            PomagierBackgroundService.isEnabled(this) -> moveTaskToBack(true)
            else -> super.onBackPressed()
        }
    }
}
