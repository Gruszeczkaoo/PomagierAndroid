# Pomagier by Don v1.0.16 — RAID NETWORK DIAGNOSTICS

Android 1.0.16 • userscript 8.8.23 • Brain 3.2.9

Ta wersja dodaje zakładkę **🚨 Napady** i bezpieczny tryb diagnostyczny potrzebny do zbudowania automatu napadów bez zgadywania endpointów.

Diagnostyka zapisuje:
- kliknięcia wykonywane ręcznie w grze,
- cały same-origin ruch `/api/` podczas krótkiego testu,
- request body, status i odpowiedź serwera,
- wysyłane i odbierane wiadomości WebSocket,
- co 10 sekund stan `activeRaid`, uczestników, lokację, status i czasy,
- rekomendację Braina i listę dostępnych lokacji, jeśli są już zsynchronizowane.

Nie zapisuje nagłówków HTTP, cookies ani Authorization. Pola token/auth/password/secret/session są maskowane.

Plan testu:
1. TEST UTWORZENIA: rozpocznij diagnostykę → ręcznie utwórz zwykły napad → wyślij na czacie gangu `napad` → wyślij to jako powiadomienie → zakończ i eksportuj JSON.
2. TEST KOŃCA: przy trwającym napadzie rozpocznij diagnostykę przed końcem → poczekaj do zera → ręcznie odbierz nagrodę → utwórz kolejny zwykły napad → `napad` + powiadomienie → zakończ i eksportuj JSON.

Eksport:
`pomagier_raid_network_trace_*.json`

W tej wersji skrypt jeszcze NIE tworzy ani nie uruchamia napadów automatycznie. Docelowo START samego napadu pozostanie ręczny dla liderów. Wykluczone z automatycznego tworzenia będą: garaże na Śródmieściu, Luksusowy garaż i Media Markt.
