# Pomagier by Don v1.0.14 — MENEL DIRECT API + SWEEP FIX

Android 1.0.14 • userscript 8.8.21 • Brain 3.2.9

Ta wersja powstała z prawdziwego śladu sieciowego MenelMode z Androida.

Najważniejsze poprawki:
- automatyczne zakończenie MenelMode używa dokładnie kolejności gry:
  1. POST `/api/scavenging/{id}/menel-mode/complete`
  2. POST `/api/scavenging/{id}/menel-mode/clear-result`
  3. świeży resync postaci, statusu MenelMode i świata
- nie używa już samego `clear-result` jako głównej ścieżki, więc nie pomija etapu naliczenia nagrody
- transakcja COMPLETE -> CLEAR jest zapisywana po fingerprintcie wyniku, aby po wznowieniu aplikacji nie powtórzyć naliczania tej samej nagrody
- po darmowym zakończeniu podróży i normalnym przyjeździe Pomagier natychmiast odświeża świat, dzięki czemu Brain nie powinien widzieć starej dzielnicy
- Brain 3.2.9 naprawia przejście SWEEP -> HUSTLE: jeżeli w tym samym cyklu są już nowe białe dzielnice, Kombinowanie nie może wystartować między nimi
- dodatkowa ochrona ponownie uzbraja SWEEP, jeśli aplikacja wznowi się ze starym stanem HUSTLE, ale `/all-cooldowns` pokazuje białe dzielnice
- diagnostyka MenelMode blokuje teraz także automatyczne Kombinowanie podczas ręcznego testu

Wersja zachowuje Alcohol DIRECT API z v1.0.12 oraz diagnostykę MenelMode z v1.0.13.
