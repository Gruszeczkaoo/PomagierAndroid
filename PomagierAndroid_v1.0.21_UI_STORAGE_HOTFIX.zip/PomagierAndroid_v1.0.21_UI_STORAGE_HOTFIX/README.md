# Pomagier by Don v1.0.21 — WYPŁATY GANGU

Android 1.0.20 • userscript 8.8.28 • Brain 3.2.9

## 1. Nowa zakładka: 💰 Wypłaty

Zakładka służy do ręcznego, tygodniowego ustawiania dziennych pensji w spółce gangu.

Pomagier nie uruchamia rozliczenia sam w sobotę. Użytkownik zawsze:
1. wchodzi w `💰 Wypłaty`,
2. sprawdza zakres dat i pulę,
3. klika `Pobierz wpłaty`,
4. ogląda pełny podgląd,
5. dopiero ręcznie klika `Ustaw pensje w grze`.

Domyślny zakres to **7 pełnych zakończonych dni**. Jeżeli rozliczenie robisz w sobotę, domyślnie wychodzi poprzednia sobota–piątek. Daty `Od` / `Do` można zmienić ręcznie.

Domyślna pula dzienna to **100 000 zł**, ale pole można zmienić.

### Dane używane przez Pomagiera

Historia wpłat:

`GET /api/gangs/{characterId}/treasury/history/report?period=custom&members=all&from=YYYY-MM-DD&to=YYYY-MM-DD&dayPage=1`

Kadry:

`GET /api/gangs/{characterId}/company/employees`

Dane spółki / limity:

`GET /api/gangs/{characterId}/company`

Zapis jednej pensji:

`PATCH /api/gangs/{characterId}/company/employees/{employeeId}`

Body jest zgodne z aktualnym flow gry:

```json
{
  "salary": 1234,
  "positionTitle": "Pracownik Firmy"
}
```

## 2. Dokładne liczenie 100 000 zł

Podział nie korzysta z zaokrąglonego procentu pokazywanego w interfejsie gry.

Dla każdego gracza:

`udział = dokładna kwota wpłat gracza / suma dokładnych wpłat wszystkich graczy`

`pensja = udział × pula dzienna`

Pensje w spółce są ustawiane jako pełne złotówki. Pomagier najpierw zaokrągla w dół, a pozostałe złotówki rozdziela metodą **największych reszt**. Dzięki temu suma wszystkich nowych pensji wynosi dokładnie wpisaną pulę, np. **100 000 zł**.

## 3. Kontrole przed zapisem

Pomagier nie zapisze pensji, jeśli wykryje problem, m.in.:
- etatowiec ma 0 zł wpłat,
- wpłacający nie ma etatu w spółce,
- wpłacający nie jest już bieżącym członkiem gangu,
- wyliczona pensja byłaby niższa niż minimalna pensja gry,
- pula przekracza dzienny dochód spółki,
- konto nie ma `canManageCompany`,
- zakres dat zmienił się od ostatniego pobrania danych.

Nowi członkowie, którzy mają 0 wpłat i nie są zatrudnieni w spółce, nie blokują rozliczenia.

## 4. Bezpieczny zapis serii pensji

Przed właściwym zapisem Pomagier ponownie pobiera świeżą historię wpłat i aktualne kadry.

Następnie:
- zmiany obniżające pensje wykonuje najpierw,
- podwyżki wykonuje później,
- po całej serii ponownie pobiera kadry i weryfikuje każdą pensję,
- jeśli któryś PATCH nie powiedzie się albo weryfikacja wykryje różnicę, próbuje przywrócić już zmienione pensje do poprzednich wartości.

W zakładce jest zapisywana krótka lokalna historia ostatnich rozliczeń: zakres, pula, suma wpłat i pensje graczy.

## 5. Funkcje z v1.0.19 pozostają

Zachowane są m.in.:
- Security Lab z poprawionym zapisem/eksportem,
- automatyczne napady,
- Alkohol DIRECT API,
- automatyczny demontaż Drożdży winiarskich z plecaka/rupieciarni,
- PvP Lab i Boss Lab,
- główny Pomagier / Brain.

## 6. Jeden workflow GitHub

Używaj tylko:

`.github/workflows/build-apk.yml`

Workflow obsługuje zarówno pełny projekt Android w repo, jak i najnowszy plik `PomagierAndroid_v*.zip` w katalogu głównym.

Po udanym buildzie próbuje jednorazowo usunąć wszystkie stare `.yml/.yaml` z `.github/workflows/`, pozostawiając tylko `build-apk.yml`. Commit sprzątający używa `[skip ci]`, żeby nie tworzyć kolejnej lawiny buildów.

Jeżeli GitHub nie pozwoli tokenowi workflow zmieniać plików workflow, sam build APK nadal zakończy się normalnie, a w logu pojawi się ostrzeżenie. Wtedy stare workflowy trzeba usunąć ręcznie lub nadać odpowiednie uprawnienia repozytorium.


## Hotfix v1.0.21
- Naprawa blokowania zakładek przy pełnym localStorage (QuotaExceededError).
- Awaryjna kompakcja cache PvP Lab przy braku miejsca.
- Granica błędu renderowania UI zamiast pozostawiania zawartości poprzedniej zakładki.
- Zachowana zakładka Wypłaty gangu.
