# Pomagier by Don — Android v1.0.2

Pełna aplikacja Android dla Menelgame z wbudowanym **Pomagierem 8.8.11** i lokalnym **Pomagier AI Brain 3.2.7**.

## Co działa

- Menelgame działa wewnątrz WebView; logowanie i cookies zostają w aplikacji.
- Pomagier 8.8.11 jest wstrzykiwany automatycznie przy starcie dokumentu — bez Tampermonkey.
- Brain 3.2.7 działa lokalnie w APK przez Chaquopy (JS → Kotlin → Python), bez komputera i bez localhost HTTP.
- SQLite Braina jest trwały w pamięci aplikacji.
- Eksporty JSON/CSV zapisują się do `Pobrane/PomagierByDon/`.
- Długie przytrzymanie 🧠 eksportuje bazę Braina.
- Menu ⋮ umożliwia eksport DB/logu, czyszczenie cache, reset danych gry i przejście do ustawień aplikacji/baterii.
- Tryb nocny utrzymuje WebView aktywny, ustawia jasność na 1%, pokazuje czarną kurtynę i blokuje przypadkowe dotknięcia.
- Automatyczny recovery po awarii procesu WebView.
- Obsługa błędu połączenia z przyciskiem ponowienia.
- Debugowanie WebView jest włączone tylko w buildzie debug.

## Wersje

- Android app: **1.0.0**
- Pomagier userscript: **8.8.11**
- Brain: **3.2.7**
- minSdk: 29 (Android 10+)
- targetSdk/compileSdk: 35
- ABI: arm64-v8a + x86_64

## Budowanie APK

### GitHub Actions
Po wrzuceniu całego projektu do repozytorium GitHub workflow `.github/workflows/build-apk.yml` buduje podpisany `Pomagier-by-Don-v1.0.0.apk` i plik SHA-256. W GitHub: **Actions → Build Pomagier Android APK → Run workflow** albo zwykły push do `main`. Projekt zawiera prywatny klucz podpisu przeznaczony wyłącznie do osobistych buildów sideload, dzięki czemu kolejne wersje mogą aktualizować aplikację bez utraty danych.

### Android Studio
1. Otwórz katalog projektu.
2. Poczekaj na Gradle Sync.
3. `Build → Build Bundle(s) / APK(s) → Build APK(s)`.
4. APK release: `app/build/outputs/apk/release/app-release.apk`.

## Tryb nocny
Tryb nocny działa wtedy, gdy aplikacja pozostaje na pierwszym planie. Ekran jest praktycznie czarny, ale pozostaje aktywny, dzięki czemu WebView i timery JavaScript nie są zatrzymywane przez `onPause`. Android/OEM nadal może stosować własne mechanizmy oszczędzania energii — w menu jest skrót do ustawień aplikacji/baterii.

## Bezpieczeństwo

- HTTP cleartext jest wyłączony.
- Linki poza `menelgame.online` otwierają się w zewnętrznej przeglądarce.
- Dostęp do plików lokalnych z WebView jest wyłączony.
- Backup systemowy aplikacji jest wyłączony, aby nie kopiować cookies/logowania.
- Brain nie otrzymuje cookies ani tokenu logowania z Menelgame; dostaje tylko payload decyzyjny z userscriptu.

## Podpis APK

Projekt zawiera `app/pomagier-local.jks`, używany wyłącznie do osobistych instalacji poza Google Play. Nie publikuj tego klucza w publicznym repozytorium. Zachowaj go, bo kolejne APK muszą używać tego samego podpisu, aby Android pozwolił zaktualizować aplikację bez odinstalowania i utraty danych.


## v1.0.2 — Session Fix
- Android/WebView: sesja API może zostać odtworzona w RAM z aktualnego `menelgame_user.token`, bez czekania na przechwycenie requestu Bazaru/Warsztatu.
- Token nie jest zapisywany do logów, eksportów ani bazy Braina.
- Fallback działa również, gdy logowanie zakończy się wewnątrz SPA bez pełnego przeładowania strony.


## v1.0.2 — Android UI fix
- ruchomy panel Pomagiera palcem (Pointer Events)
- zmiana rozmiaru panelu palcem
- przycisk minimalizacji dostępny w mobilnym nagłówku
- sensowny domyślny rozmiar panelu zamiast wymuszonego full-screen
- natywny przycisk P nie resetuje już geometrii panelu
- górny pasek systemowy Androida (godzina/bateria/Wi‑Fi) jest ukryty w normalnym trybie aplikacji
- dolna nawigacja Androida pozostaje dostępna
