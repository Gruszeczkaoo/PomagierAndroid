# Pomagier by Don v1.0.19 — SECURITY LAB FIX + DROŻDŻE

Android 1.0.19 • userscript 8.8.26 • Brain 3.2.9

## 1. Security Lab — naprawiony eksport 24 h

W v1.0.18 licznik Security Lab rósł, ale rekordy zapisywane do IndexedDB miały wewnętrzne `sessionId`
zredagowane do `[REDACTED]`. Eksport wyszukiwał prawdziwy ID sesji i dlatego zwracał `storedEventCount: 0`.

v1.0.19:
- zapisuje prawdziwy wewnętrzny `sessionId` jako klucz indeksu, ale nadal nie zapisuje tokenów/cookies/Authorization,
- potrafi odzyskać starą sesję v1.0.18, jeśli jej IndexedDB nadal istnieje po aktualizacji,
- przed rozpoczęciem nowej sesji wymaga eksportu poprzedniej albo świadomego użycia „Wyczyść bazę”,
- na Androidzie eksportuje jeden JSON strumieniowo porcjami, więc nie musi składać całych 24 h do jednego ogromnego Stringa,
- w eksporcie zapisuje `storedEventCount`, `storageMode` oraz `recoveredLegacyV1`.

### Ważne po instalacji v1.0.19

Najpierw wejdź w `🛡️ Security Lab` i kliknij `Eksportuj jeden JSON`.
Jeżeli stara baza v1.0.18 nadal jest w aplikacji, Pomagier spróbuje odzyskać poprzednie ~24 h.
Dopiero po udanym eksporcie uruchom nową sesję.

## 2. Drożdże winiarskie — automatyczny demontaż

`Drożdże winiarskie` mają `item_id = 222`.

To jedyny jawny wyjątek od ochrony składników craftu/kolekcji:
- można je ręcznie dodać do demontażu,
- przy włączonym głównym Pomagierze i `Automatyczny demontaż` Pomagier sam wypełnia nimi wolne sloty kolejki,
- najpierw bierze Drożdże z plecaka,
- gdy w plecaku ich nie ma, sprawdza rupieciarnię, wyjmuje stack i natychmiast dodaje Drożdże do demontażu,
- Guardian nie odkłada Drożdży z powrotem do rupieciarni,
- serwerowa blokada `is_dismantle_locked` nadal jest respektowana,
- w DRY RUN nic nie jest przenoszone ani demontowane.

Potwierdzony flow gry dla Drożdży:
`POST /api/workshop/{characterId}/queue/add` z `inventoryId`.
Serwer zwraca wpis kolejki z `item_id: 222`, czasem i uzyskiem.

## 3. Jeden workflow GitHub od teraz

Do repo używaj wyłącznie:

`.github/workflows/build-apk.yml`

Nowy workflow:
- ma stałą nazwę `Build Pomagier Android APK`,
- sam wybiera najwyższą wersję `PomagierAndroid_v*.zip` z katalogu głównego repo,
- przy pierwszym uruchomieniu próbuje usunąć wszystkie stare pliki `.yml/.yaml` z `.github/workflows/`,
  pozostawiając tylko `build-apk.yml`,
- kolejne wersje nie potrzebują nowych workflowów,
- artefakt APK dostaje wersję odczytaną z `app/build.gradle.kts`.

Jeżeli automatyczne sprzątanie nie będzie mogło wykonać `git push`, workflow wyświetli ostrzeżenie.
Wtedy w GitHub: `Settings -> Actions -> General -> Workflow permissions` ustaw `Read and write permissions`
i uruchom `build-apk.yml` jeszcze raz.

## Bezpieczeństwo

Security Lab podczas nagrywania jest pasywny. Nie wykonuje fuzzingu ani testowych prób.
Nie zapisuje nagłówków HTTP, Authorization, cookies, tokenów, haseł, danych sesyjnych, e-maila ani device ID.
