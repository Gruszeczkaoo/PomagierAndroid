# Pomagier by Don v1.0.18 — SECURITY LAB 24H

Android 1.0.18 • userscript 8.8.25 • Brain 3.2.9

## Nowa zakładka: 🛡️ Security Lab

Security Lab to **pasywny rejestr diagnostyczny** przeznaczony do długiego audytu zachowania klienta i API.

Po kliknięciu `START 24H`:
- nagrywanie działa niezależnie od głównego ON/OFF Pomagiera,
- działa maksymalnie 24 godziny i automatycznie zatrzyma się po tym czasie,
- dane są zapisywane w IndexedDB, więc nie są ograniczone małym localStorage,
- sesja może być kontynuowana po przeładowaniu WebView,
- Androidowy tryb podtrzymania aktywności traktuje Security Lab jako aktywną automatyzację.

Rejestrowane są:
- wszystkie same-origin requesty `/api/` wykonywane przez grę,
- wszystkie same-origin requesty `/api/` wykonywane wewnętrznie przez Pomagiera,
- metoda, ścieżka, request body, status HTTP, czas odpowiedzi, response body,
- `source: "game"` albo `source: "pomagier"`,
- kliknięcia,
- zmiany tras/history/hash,
- focus/blur/visibility/online/offline,
- WebSocket send/receive,
- heartbeat + snapshot ekonomii co 60 sekund,
- pomocnicze `economySignals` dla pól związanych z gotówką, puszkami, nagrodami i monetami 277/278/279.

Security Lab **nie zapisuje nagłówków HTTP**. Redagowane są Authorization, cookies, tokeny, hasła, dane sesyjne, e-mail i identyfikatory urządzenia.

Przycisk `Eksportuj jeden JSON` tworzy jeden plik:
`pomagier_security_lab_<START>_24h.json`

Security Lab sam nie wykonuje fuzzingu ani dodatkowych requestów — tylko obserwuje rzeczywisty ruch gry i Pomagiera.
