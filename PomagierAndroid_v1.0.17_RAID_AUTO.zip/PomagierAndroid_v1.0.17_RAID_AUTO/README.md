# Pomagier by Don v1.0.17 — RAID AUTO

Android 1.0.17 • userscript 8.8.24 • Brain 3.2.9

## Napady — automat ON/OFF

W zakładce `🚨 Napady` jest niezależny przełącznik:
`Automatyczne napady — ON/OFF`.

Po włączeniu automat działa według potwierdzonego trace'a z gry:

1. GET `/api/gangs/{characterId}/active-raid`
2. Gdy nie ma planu: GET `/api/gangs/{characterId}/raid-locations`
3. Wybór najwyższego dostępnego dozwolonego napadu według `sort_order`
4. POST `/api/gangs/{characterId}/raid/plan` z `{locationId}`
5. POST `/api/gangs/{characterId}/chat/announce` z `{message:"Napad"}`
   - daje wiadomość `📢 Napad` na czacie gangu
   - oraz powiadomienie `gangAnnouncement`
6. Status `planning`: automat WYŁĄCZNIE czeka. Nie wywołuje START-u.
7. Lider ręcznie uruchamia napad.
8. Status `in_progress`: automat czeka do `ends_at`.
9. Status `completed`: POST `/api/gangs/{characterId}/raid/acknowledge` z `{planId}`.
10. Po zamknięciu wyniku automat planuje kolejny dozwolony napad i ponownie wysyła `Napad`.

## Twardo wykluczone z automatu

- #20 Garaże na Śródmieściu
- #21 Luksusowy garaż
- #22 Media Market

Te trzy lokalizacje nigdy nie są automatycznie planowane. Ich uruchamianie pozostaje ręczne.

## Bezpieczeństwo / odporność

- Domyślnie automat Napadów jest WYŁĄCZONY po aktualizacji.
- Diagnostyka Napadów automatycznie wyłącza automat, aby nie mieszać requestów.
- Stan planu, ogłoszenia i acknowledge jest zapisywany w localStorage.
- Po niejednoznacznym błędzie ogłoszenia Pomagier sprawdza czat przed ponowną wysyłką, aby ograniczyć duplikaty.
- Automat nie zawiera i nie wywołuje endpointu START napadu.
