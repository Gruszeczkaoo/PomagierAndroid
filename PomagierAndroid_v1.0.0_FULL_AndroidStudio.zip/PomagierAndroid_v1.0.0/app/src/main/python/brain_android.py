# -*- coding: utf-8 -*-
"""Android bridge for Pomagier AI Brain 3.2.7.

The Android app calls the Brain directly through Chaquopy. No localhost HTTP
server, cookies or Menelgame tokens are exposed to Python.
"""
from __future__ import annotations

import hashlib
import json
import os
import threading
import traceback

_LOCK = threading.RLock()
_BRAIN = None
_INIT_ERROR = ""


def init(home: str) -> str:
    global _BRAIN, _INIT_ERROR
    with _LOCK:
        if _BRAIN is not None:
            return status_json()
        try:
            os.makedirs(home, exist_ok=True)
            os.environ["POMAGIER_BRAIN_HOME"] = home
            import brain  # imported only after the writable home is configured
            brain.init_db()
            integrity = brain.db_integrity()
            brain.BRAIN_HEALTH = "OK" if integrity == "ok" else f"DB:{integrity}"
            try:
                brain.maintenance_backup()
            except Exception as exc:
                brain.log(f"ANDROID backup warning: {type(exc).__name__}: {exc}")
            # Android doesn't ship Ollama. Keep the local reviewer explicitly off.
            brain.LAST_LLM_STATUS = {
                "status": "OFF_ANDROID",
                "model": "",
                "last_error": "",
                "last_review": 0,
            }
            _BRAIN = brain
            _INIT_ERROR = ""
            brain.log("Pomagier AI Brain v3.2.7 ONLINE — Android direct bridge")
            return status_json()
        except Exception as exc:
            _INIT_ERROR = f"{type(exc).__name__}: {exc}"
            return json.dumps({"ok": False, "error": _INIT_ERROR, "trace": traceback.format_exc(limit=6)}, ensure_ascii=False)


def _authorized(payload: dict) -> bool:
    brain = _BRAIN
    if brain is None:
        return False
    expected = str(brain.CFG.get("bridge_token") or "")
    got = str(payload.get("bridgeToken") or "")
    return bool(expected) and hashlib.sha256(got.encode()).digest() == hashlib.sha256(expected.encode()).digest()


def decide_json(payload_json: str) -> str:
    with _LOCK:
        if _BRAIN is None:
            return json.dumps({"ok": False, "error": _INIT_ERROR or "Brain not initialized"}, ensure_ascii=False)
        try:
            payload = json.loads(payload_json)
            if not isinstance(payload, dict):
                raise ValueError("JSON musi być obiektem")
            if not _authorized(payload):
                return json.dumps({"ok": False, "error": "bad bridge token"}, ensure_ascii=False)
            result = _BRAIN.decide(payload)
            return json.dumps(result, ensure_ascii=False, separators=(",", ":"))
        except Exception as exc:
            try:
                _BRAIN.log(f"ANDROID ERROR: {type(exc).__name__}: {exc}")
                for line in traceback.format_exc(limit=12).rstrip().splitlines():
                    _BRAIN.log(f"TRACE: {line}")
            except Exception:
                pass
            return json.dumps({"ok": False, "error": f"{type(exc).__name__}: {exc}"}, ensure_ascii=False)


def memory_json() -> str:
    with _LOCK:
        if _BRAIN is None:
            return json.dumps({"ok": False, "error": _INIT_ERROR or "Brain not initialized"}, ensure_ascii=False)
        try:
            return json.dumps({"ok": True, "memory": _BRAIN.memory_summary()}, ensure_ascii=False)
        except Exception as exc:
            return json.dumps({"ok": False, "error": f"{type(exc).__name__}: {exc}"}, ensure_ascii=False)


def status_json() -> str:
    brain = _BRAIN
    if brain is None:
        return json.dumps({"ok": False, "status": "ERROR" if _INIT_ERROR else "STARTING", "error": _INIT_ERROR}, ensure_ascii=False)
    try:
        mem = brain.memory_summary()
        return json.dumps({
            "ok": True,
            "status": str(brain.BRAIN_HEALTH or "OK"),
            "brainVersion": "3.2.7",
            "dbIntegrity": brain.db_integrity(),
            "events": int(mem.get("events") or 0),
            "decisions": int(mem.get("decisions") or 0),
            "db": str(brain.DB_PATH),
        }, ensure_ascii=False)
    except Exception as exc:
        return json.dumps({"ok": False, "status": "ERROR", "error": f"{type(exc).__name__}: {exc}"}, ensure_ascii=False)
