#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Pomagier AI Brain v3.2.7 — TRAVEL ARRIVAL FIX

Lokalny agent decyzyjny:
- ekonomia / crafting,
- MenelMode,
- kombinowanie (hustling),
- NPC,
- puszki i podróże,
- bezpieczne kolekcje,
- tanie przysługi,
- obserwacja napadów,
- zadania,
- opcjonalny doradca OpenAI API.

Nie ma cookies/tokenów Menelgame i nie wykonuje requestów do gry.
Wszystkie akcje przechodzą ponowną walidację w userscripcie.
"""

from __future__ import annotations

import hashlib
import html
import json
import math
import os
import random
import shutil
import sqlite3
import threading
import time
import traceback
import urllib.request
import urllib.error
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any

ROOT = Path(os.environ.get("POMAGIER_BRAIN_HOME") or Path(__file__).resolve().parent)
CONFIG_PATH = ROOT / "config.json"
DB_PATH = ROOT / "pomagier_ai.db"
LOG_PATH = ROOT / "pomagier_ai.log"

DEFAULT_CONFIG = {
    "bind": "127.0.0.1",
    "port": 8765,
    "bridge_token": "",
    "recipe_prior_strength": 4.0,
    "exploration_strength": 0.08,
    "return_penalty": 0.22,
    "max_recipe_adjustment": 0.40,
    "district_exploration_chance": 0.12,
    "self_tuning": {
        "enabled": True,
        "ema_alpha": 0.22,
        "ucb_strength": 0.10,
        "min_exploration": 0.02,
        "max_exploration": 0.12
    },
    "local_llm": {
        "enabled": True,
        "base_url": "http://127.0.0.1:11434",
        "model": "",
        "review_interval_seconds": 180,
        "timeout_seconds": 18,
        "max_score_sacrifice_pct": 20
    },
    "backups": {
        "enabled": True,
        "retain_days": 14
    },
    "menel_mode": {
        "enabled": True,
        "allow_complete_now": False,
        "can_value_pln": 0.12
    },
    "openai_advisor": {
        "enabled": False,
        "model": "gpt-5.4-mini",
        "interval_minutes": 60,
        "max_output_tokens": 500
    }
}

LOCK = threading.RLock()
LAST_ADVISOR_AT = 0.0
LAST_ADVISOR_NOTE = "OFF"
LAST_LLM_REVIEW_AT = 0.0
LAST_LLM_STATUS = {"status":"OFF","model":"","last_error":"","last_review":0}
LAST_LLM_PICK = None
LAST_RECIPE_LLM_REVIEW_AT = 0.0
LAST_RECIPE_LLM_PICK = None
LAST_RECIPE_LLM_NOTE = ""
BRAIN_HEALTH = "STARTING"
LAST_DISTRICT_SWEEP = {}


def as_dict(value: Any) -> dict[str, Any]:
    """Return a mapping for optional JSON objects; JSON null must never break .get chains."""
    return value if isinstance(value, dict) else {}


def load_config() -> dict[str, Any]:
    if not CONFIG_PATH.exists():
        CONFIG_PATH.write_text(json.dumps(DEFAULT_CONFIG, ensure_ascii=False, indent=2), encoding="utf-8")
    cfg = json.loads(CONFIG_PATH.read_text(encoding="utf-8"))
    merged = dict(DEFAULT_CONFIG)
    merged.update(cfg)

    mm = dict(DEFAULT_CONFIG["menel_mode"])
    mm.update(cfg.get("menel_mode") or {})
    merged["menel_mode"] = mm

    oa = dict(DEFAULT_CONFIG["openai_advisor"])
    oa.update(cfg.get("openai_advisor") or {})
    merged["openai_advisor"] = oa

    st = dict(DEFAULT_CONFIG["self_tuning"])
    st.update(cfg.get("self_tuning") or {})
    merged["self_tuning"] = st

    llm = dict(DEFAULT_CONFIG["local_llm"])
    llm.update(cfg.get("local_llm") or {})
    merged["local_llm"] = llm

    backups = dict(DEFAULT_CONFIG["backups"])
    backups.update(cfg.get("backups") or {})
    merged["backups"] = backups

    return merged


CFG = load_config()


def log(msg: str) -> None:
    line = f"{time.strftime('%Y-%m-%d %H:%M:%S')}  {msg}"
    print(line, flush=True)
    try:
        with LOG_PATH.open("a", encoding="utf-8") as f:
            f.write(line + "\n")
    except Exception:
        pass


def db() -> sqlite3.Connection:
    con = sqlite3.connect(DB_PATH, timeout=20)
    con.row_factory = sqlite3.Row
    con.execute("PRAGMA journal_mode=WAL")
    con.execute("PRAGMA synchronous=NORMAL")
    return con


def init_db() -> None:
    with db() as con:
        con.executescript(
            """
            CREATE TABLE IF NOT EXISTS seen_events (
              event_key TEXT PRIMARY KEY,
              ts INTEGER NOT NULL,
              kind TEXT NOT NULL
            );

            CREATE TABLE IF NOT EXISTS recipe_stats (
              recipe_id INTEGER PRIMARY KEY,
              name TEXT NOT NULL DEFAULT '',
              sold INTEGER NOT NULL DEFAULT 0,
              returned INTEGER NOT NULL DEFAULT 0,
              n_profit INTEGER NOT NULL DEFAULT 0,
              mean_profit_hour REAL,
              mean_profit REAL,
              mean_sale_minutes REAL,
              mean_prediction_ratio REAL,
              updated_at INTEGER NOT NULL DEFAULT 0
            );

            CREATE TABLE IF NOT EXISTS menel_stats (
              district TEXT PRIMARY KEY,
              runs INTEGER NOT NULL DEFAULT 0,
              mean_reward REAL,
              mean_cash REAL,
              mean_cans REAL,
              mean_item_value REAL,
              mean_duration REAL,
              updated_at INTEGER NOT NULL DEFAULT 0
            );

            CREATE TABLE IF NOT EXISTS hustling_stats (
              type_id INTEGER PRIMARY KEY,
              name TEXT NOT NULL DEFAULT '',
              runs INTEGER NOT NULL DEFAULT 0,
              interrupted INTEGER NOT NULL DEFAULT 0,
              mean_earnings REAL,
              mean_minutes REAL,
              mean_earnings_hour REAL,
              updated_at INTEGER NOT NULL DEFAULT 0
            );

            CREATE TABLE IF NOT EXISTS npc_stats (
              npc_id INTEGER PRIMARY KEY,
              name TEXT NOT NULL DEFAULT '',
              attacks INTEGER NOT NULL DEFAULT 0,
              wins INTEGER NOT NULL DEFAULT 0,
              mean_money REAL,
              mean_item_value REAL,
              mean_reward REAL,
              mean_energy REAL,
              mean_reward_energy REAL,
              updated_at INTEGER NOT NULL DEFAULT 0
            );

            CREATE TABLE IF NOT EXISTS can_sales (
              district TEXT PRIMARY KEY,
              sales INTEGER NOT NULL DEFAULT 0,
              mean_price REAL,
              mean_amount REAL,
              mean_earnings REAL,
              updated_at INTEGER NOT NULL DEFAULT 0
            );

            CREATE TABLE IF NOT EXISTS raid_stats (
              location_id INTEGER PRIMARY KEY,
              name TEXT NOT NULL DEFAULT '',
              observations INTEGER NOT NULL DEFAULT 0,
              completed INTEGER NOT NULL DEFAULT 0,
              successes INTEGER NOT NULL DEFAULT 0,
              mean_money REAL,
              mean_duration_minutes REAL,
              updated_at INTEGER NOT NULL DEFAULT 0
            );

            CREATE TABLE IF NOT EXISTS collection_stats (
              collection_id INTEGER PRIMARY KEY,
              name TEXT NOT NULL DEFAULT '',
              deposits INTEGER NOT NULL DEFAULT 0,
              deposited_value REAL NOT NULL DEFAULT 0,
              updated_at INTEGER NOT NULL DEFAULT 0
            );

            CREATE TABLE IF NOT EXISTS world_snapshots (
              id INTEGER PRIMARY KEY AUTOINCREMENT,
              ts INTEGER NOT NULL,
              district TEXT,
              money REAL,
              cans REAL,
              energy REAL,
              payload_json TEXT
            );

            CREATE TABLE IF NOT EXISTS decisions (
              id INTEGER PRIMARY KEY AUTOINCREMENT,
              ts INTEGER NOT NULL,
              preferred_recipe_id INTEGER,
              preferred_recipe_name TEXT,
              recipe_score REAL,
              action_type TEXT,
              action_label TEXT,
              reason TEXT
            );

            CREATE TABLE IF NOT EXISTS meta (
              key TEXT PRIMARY KEY,
              value TEXT
            );

            CREATE TABLE IF NOT EXISTS action_stats (
              action_key TEXT PRIMARY KEY,
              action_type TEXT NOT NULL,
              context TEXT NOT NULL DEFAULT '',
              samples INTEGER NOT NULL DEFAULT 0,
              successes INTEGER NOT NULL DEFAULT 0,
              failures INTEGER NOT NULL DEFAULT 0,
              mean_reward REAL,
              ema_reward REAL,
              m2_reward REAL NOT NULL DEFAULT 0,
              mean_duration REAL,
              last_reward REAL,
              last_ts INTEGER NOT NULL DEFAULT 0
            );

            CREATE TABLE IF NOT EXISTS policy_reflections (
              id INTEGER PRIMARY KEY AUTOINCREMENT,
              ts INTEGER NOT NULL,
              source TEXT NOT NULL,
              selected_action_key TEXT,
              note TEXT
            );
            """
        )


def meta_get_json(key: str, default: Any = None) -> Any:
    try:
        with db() as con:
            row=con.execute("SELECT value FROM meta WHERE key=?",(key,)).fetchone()
        if not row:
            return default
        return json.loads(str(row["value"]))
    except Exception:
        return default


def meta_set_json(key: str, value: Any) -> None:
    raw=json.dumps(value,ensure_ascii=False,separators=(",",":"))
    with db() as con:
        con.execute(
            "INSERT INTO meta(key,value) VALUES(?,?) "
            "ON CONFLICT(key) DO UPDATE SET value=excluded.value",
            (key,raw)
        )


def meta_delete(key: str) -> None:
    with db() as con:
        con.execute("DELETE FROM meta WHERE key=?",(key,))


def db_integrity() -> str:
    try:
        with db() as con:
            row=con.execute("PRAGMA integrity_check").fetchone()
        return str(row[0] if row else "unknown")
    except Exception as e:
        return f"error:{type(e).__name__}"


def maintenance_backup() -> None:
    cfg=CFG.get("backups") or {}
    if not cfg.get("enabled",True) or not DB_PATH.exists():
        return
    d=ROOT/"backups"
    d.mkdir(exist_ok=True)
    target=d/f"pomagier_ai_{time.strftime('%Y%m%d')}.db"
    if not target.exists():
        try:
            with db() as src, sqlite3.connect(target) as dst:
                src.backup(dst)
            log(f"Backup pamięci AI: {target.name}")
        except Exception as e:
            log(f"Backup error: {type(e).__name__}: {e}")
    cutoff=time.time()-max(3,int(cfg.get("retain_days") or 14))*86400
    for p in d.glob("pomagier_ai_*.db"):
        try:
            if p.stat().st_mtime<cutoff: p.unlink()
        except Exception:
            pass


def action_key(action_type: str, entity: Any="", context: str="") -> str:
    return f"{action_type}:{entity}:{context}"


def update_action_stat(key: str, action_type: str, context: str, reward: float|None, success: bool, duration: float|None=None, ts: int|None=None) -> None:
    ts=int(ts or time.time()*1000)
    alpha=max(0.03,min(0.80,float((CFG.get("self_tuning") or {}).get("ema_alpha") or 0.22)))
    with LOCK, db() as con:
        row=con.execute("SELECT * FROM action_stats WHERE action_key=?",(key,)).fetchone()
        if row is None:
            con.execute("""
              INSERT INTO action_stats(action_key,action_type,context,samples,successes,failures,mean_reward,ema_reward,m2_reward,mean_duration,last_reward,last_ts)
              VALUES(?,?,?,?,?,?,?,?,?,?,?,?)
            """,(key,action_type,context,1,1 if success else 0,0 if success else 1,reward,reward,0.0,duration,reward,ts))
            return
        n=int(row["samples"])
        mean_old=row["mean_reward"]
        mean_new=mean_old
        m2=float(row["m2_reward"] or 0)
        m2_new=m2
        if reward is not None and math.isfinite(float(reward)):
            reward=float(reward)
            if mean_old is None:
                mean_new=reward; m2_new=0.0
            else:
                delta=reward-float(mean_old)
                mean_new=float(mean_old)+delta/(n+1)
                m2_new=m2+delta*(reward-mean_new)
        ema_old=row["ema_reward"]
        ema_new=reward if ema_old is None else (float(ema_old) if reward is None else float(ema_old)*(1-alpha)+float(reward)*alpha)
        dur_new=mean_update(row["mean_duration"],n,duration)
        con.execute("""
          UPDATE action_stats SET samples=?,successes=?,failures=?,mean_reward=?,ema_reward=?,m2_reward=?,mean_duration=?,last_reward=?,last_ts=?
          WHERE action_key=?
        """,(n+1,int(row["successes"])+(1 if success else 0),int(row["failures"])+(0 if success else 1),mean_new,ema_new,m2_new,dur_new,reward,ts,key))


def get_action_stat(key: str) -> dict[str,Any]|None:
    with db() as con:
        row=con.execute("SELECT * FROM action_stats WHERE action_key=?",(key,)).fetchone()
    return dict(row) if row else None


def tuned_score(base_score: float, key: str) -> tuple[float,float,str]:
    base=float(base_score or 0)
    cfg=CFG.get("self_tuning") or {}
    if not cfg.get("enabled",True): return base,0.0,"self-tuning OFF"
    stat=get_action_stat(key)
    with db() as con:
        total=int(con.execute("SELECT COALESCE(SUM(samples),0) n FROM action_stats").fetchone()["n"])
    min_exp=max(0.0,float(cfg.get("min_exploration") or 0.02))
    max_exp=max(min_exp,float(cfg.get("max_exploration") or 0.12))
    ucb=max(0.0,float(cfg.get("ucb_strength") or 0.10))
    if not stat:
        bonus=max_exp*max(abs(base),1.0)
        return base+bonus,0.0,"nowa akcja — eksploracja"
    n=max(1,int(stat["samples"]))
    sr=(int(stat["successes"])+3.0)/(int(stat["successes"])+int(stat["failures"])+4.0)
    conf=n/(n+5.0)
    learned=stat.get("ema_reward")
    blended=base if learned is None else base*(1-conf)+float(learned)*conf
    exp_rate=max(min_exp,min(max_exp,ucb*math.sqrt(max(0.0,math.log(total+2.0)/(n+1.0)))))
    adjusted=blended*(0.75+0.25*sr)+exp_rate*max(abs(base),1.0)
    return adjusted,conf,f"{n} prób • sukces {sr*100:.0f}% • ekspl. {exp_rate*100:.1f}%"


def ingest_policy_events(events: list[dict[str,Any]]) -> None:
    for e in events or []:
        eid=str(e.get("id") or "")
        if not eid: continue
        kind=str(e.get("type") or "")
        ctx=str(e.get("districtName") or "")
        ts=int(e.get("ts") or time.time()*1000)
        # Separate dedupe namespace from domain-specific ingestion.
        with db() as con:
            if not claim_event(con,"policy:"+eid,ts,"policy_"+kind):
                continue
        if kind=="hustle_stop":
            mins=max(0.01,float(e.get("elapsedMinutes") or 0))
            reward=float(e.get("earnings") or 0)/(mins/60.0)
            update_action_stat(action_key("hustle",int(e.get("hustlingTypeId") or 0),ctx),"hustle",ctx,reward,not bool(e.get("wasInterrupted")),mins*60,ts)
            meta_delete("district_sweep_v1")
        elif kind=="npc_attack":
            energy=max(1.0,float(e.get("energyUsed") or 1))
            reward=(float(e.get("money") or 0)+float(e.get("itemValue") or 0))/energy
            update_action_stat(action_key("npc",int(e.get("npcId") or 0),ctx),"npc",ctx,reward,bool(e.get("won")),1.0,ts)

            sweep_meta=meta_get_json("district_sweep_v1",None)
            if isinstance(sweep_meta,dict) and str(sweep_meta.get("phase") or "")=="hustle":
                sweep_meta["npcAttemptedAfterSweep"]=True
                sweep_meta["npcAttemptedAt"]=ts
                meta_set_json("district_sweep_v1",sweep_meta)
        elif kind=="sell_cans":
            reward=float(e.get("canPrice") or 0)
            update_action_stat(action_key("sell_cans",ctx,ctx),"sell_cans",ctx,reward,True,1.0,ts)
        elif kind=="menel_result":
            result=e.get("result") or {}
            collecting=result.get("collecting") or {}; begging=result.get("begging") or {}; dumpster=result.get("dumpster") or {}
            cans=float(collecting.get("collected") or collecting.get("total") or 0)
            cash=float(begging.get("netEarnings") or begging.get("earned") or 0)
            itemv=0.0
            for obj in [dumpster.get("item") or {},dumpster.get("bonusItem") or {}]:
                if isinstance(obj,dict): itemv+=float(obj.get("sell_price_paser") or obj.get("paserSellPrice") or 0)
            total=cash+itemv+cans*float((CFG.get("menel_mode") or {}).get("can_value_pln") or 0.12)
            sec=max(60.0,float(e.get("estimatedDuration") or 1139))
            reward=total/(sec/3600.0)
            update_action_stat(action_key("menel",ctx,ctx),"menel",ctx,reward,True,sec,ts)
        elif kind=="collection_deposit":
            update_action_stat(action_key("collection",int(e.get("collectionId") or 0),ctx),"collection",ctx,1.0,True,1.0,ts)
        elif kind=="action_error":
            at=str(e.get("actionType") or "unknown")
            update_action_stat(action_key(at,str(e.get("label") or ""),ctx),at,ctx,0.0,False,1.0,ts)
        elif kind=="travel_complete":
            update_action_stat(action_key("travel",int(e.get("districtId") or 0),ctx),"travel",ctx,1.0,True,1.0,ts)


def mean_update(old: float | None, n_old: int, value: float | None) -> float | None:
    if value is None:
        return old
    try:
        value = float(value)
    except Exception:
        return old
    if not math.isfinite(value):
        return old
    if old is None or n_old <= 0:
        return value
    return float(old) + (value - float(old)) / (n_old + 1)


def stable_key(obj: Any) -> str:
    raw = json.dumps(obj, sort_keys=True, ensure_ascii=False, separators=(",", ":"))
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()


def claim_event(con: sqlite3.Connection, key: str, ts: int, kind: str) -> bool:
    cur = con.execute(
        "INSERT OR IGNORE INTO seen_events(event_key,ts,kind) VALUES(?,?,?)",
        (str(key), int(ts), str(kind)),
    )
    return cur.rowcount > 0


# ----------------------------------------------------------------------
# INGEST: economy learner events from v5
# ----------------------------------------------------------------------
def ingest_recipe_events(events: list[dict[str, Any]]) -> int:
    added = 0
    with LOCK, db() as con:
        for e in events or []:
            kind = str(e.get("type") or "")
            if kind not in {"sold", "returned"}:
                continue

            key = "legacy:" + stable_key(e)
            if not claim_event(con, key, int(e.get("ts") or time.time() * 1000), kind):
                continue

            rid = int(e.get("recipeId") or 0)
            if not rid:
                continue

            row = con.execute("SELECT * FROM recipe_stats WHERE recipe_id=?", (rid,)).fetchone()
            if row is None:
                con.execute(
                    "INSERT INTO recipe_stats(recipe_id,name,updated_at) VALUES(?,?,?)",
                    (rid, str(e.get("name") or ""), int(time.time() * 1000)),
                )
                row = con.execute("SELECT * FROM recipe_stats WHERE recipe_id=?", (rid,)).fetchone()

            sold = int(row["sold"])
            returned = int(row["returned"])
            n_profit = int(row["n_profit"])
            name = str(e.get("name") or row["name"] or "")

            if kind == "returned":
                returned += 1
                con.execute(
                    "UPDATE recipe_stats SET name=?, returned=?, updated_at=? WHERE recipe_id=?",
                    (name, returned, int(time.time() * 1000), rid),
                )
            else:
                ph = e.get("realizedProfitHour")
                profit = e.get("profit")
                sale_min = e.get("saleMinutes")
                ratio = e.get("predictionRatio")

                con.execute(
                    """
                    UPDATE recipe_stats
                    SET name=?, sold=?, n_profit=?,
                        mean_profit_hour=?, mean_profit=?,
                        mean_sale_minutes=?, mean_prediction_ratio=?,
                        updated_at=?
                    WHERE recipe_id=?
                    """,
                    (
                        name,
                        sold + 1,
                        n_profit + 1,
                        mean_update(row["mean_profit_hour"], n_profit, ph),
                        mean_update(row["mean_profit"], n_profit, profit),
                        mean_update(row["mean_sale_minutes"], n_profit, sale_min),
                        mean_update(row["mean_prediction_ratio"], n_profit, ratio),
                        int(time.time() * 1000),
                        rid,
                    ),
                )
            added += 1
    return added


# ----------------------------------------------------------------------
# INGEST: events generated by v7 actions
# ----------------------------------------------------------------------
def ingest_game_events(events: list[dict[str, Any]]) -> list[str]:
    ack: list[str] = []

    with LOCK, db() as con:
        for e in events or []:
            event_id = str(e.get("id") or "")
            if not event_id:
                continue

            kind = str(e.get("type") or "event")
            ts = int(e.get("ts") or time.time() * 1000)

            if not claim_event(con, "v7:" + event_id, ts, kind):
                ack.append(event_id)
                continue

            if kind == "hustle_stop":
                tid = int(e.get("hustlingTypeId") or 0)
                if tid:
                    row = con.execute("SELECT * FROM hustling_stats WHERE type_id=?", (tid,)).fetchone()
                    if row is None:
                        con.execute(
                            "INSERT INTO hustling_stats(type_id,name,updated_at) VALUES(?,?,?)",
                            (tid, str(e.get("name") or ""), ts),
                        )
                        row = con.execute("SELECT * FROM hustling_stats WHERE type_id=?", (tid,)).fetchone()

                    n = int(row["runs"])
                    earnings = float(e.get("earnings") or 0)
                    minutes = max(0.01, float(e.get("elapsedMinutes") or 0))
                    eph = earnings / (minutes / 60.0)

                    con.execute(
                        """
                        UPDATE hustling_stats
                        SET name=?,runs=?,interrupted=?,mean_earnings=?,mean_minutes=?,
                            mean_earnings_hour=?,updated_at=?
                        WHERE type_id=?
                        """,
                        (
                            str(e.get("name") or row["name"] or ""),
                            n + 1,
                            int(row["interrupted"]) + (1 if e.get("wasInterrupted") else 0),
                            mean_update(row["mean_earnings"], n, earnings),
                            mean_update(row["mean_minutes"], n, minutes),
                            mean_update(row["mean_earnings_hour"], n, eph),
                            ts,
                            tid,
                        ),
                    )

            elif kind == "npc_attack":
                nid = int(e.get("npcId") or 0)
                if nid:
                    row = con.execute("SELECT * FROM npc_stats WHERE npc_id=?", (nid,)).fetchone()
                    if row is None:
                        con.execute(
                            "INSERT INTO npc_stats(npc_id,name,updated_at) VALUES(?,?,?)",
                            (nid, str(e.get("name") or ""), ts),
                        )
                        row = con.execute("SELECT * FROM npc_stats WHERE npc_id=?", (nid,)).fetchone()

                    n = int(row["attacks"])
                    money = float(e.get("money") or 0)
                    item_value = float(e.get("itemValue") or 0)
                    reward = money + item_value
                    energy = max(1.0, float(e.get("energyUsed") or 1))
                    rpe = reward / energy

                    con.execute(
                        """
                        UPDATE npc_stats
                        SET name=?,attacks=?,wins=?,mean_money=?,mean_item_value=?,
                            mean_reward=?,mean_energy=?,mean_reward_energy=?,updated_at=?
                        WHERE npc_id=?
                        """,
                        (
                            str(e.get("name") or row["name"] or ""),
                            n + 1,
                            int(row["wins"]) + (1 if e.get("won") else 0),
                            mean_update(row["mean_money"], n, money),
                            mean_update(row["mean_item_value"], n, item_value),
                            mean_update(row["mean_reward"], n, reward),
                            mean_update(row["mean_energy"], n, energy),
                            mean_update(row["mean_reward_energy"], n, rpe),
                            ts,
                            nid,
                        ),
                    )

            elif kind == "sell_cans":
                district = str(e.get("districtName") or "?")
                row = con.execute("SELECT * FROM can_sales WHERE district=?", (district,)).fetchone()
                if row is None:
                    con.execute(
                        "INSERT INTO can_sales(district,updated_at) VALUES(?,?)",
                        (district, ts),
                    )
                    row = con.execute("SELECT * FROM can_sales WHERE district=?", (district,)).fetchone()

                n = int(row["sales"])
                con.execute(
                    """
                    UPDATE can_sales
                    SET sales=?,mean_price=?,mean_amount=?,mean_earnings=?,updated_at=?
                    WHERE district=?
                    """,
                    (
                        n + 1,
                        mean_update(row["mean_price"], n, e.get("canPrice")),
                        mean_update(row["mean_amount"], n, e.get("cans")),
                        mean_update(row["mean_earnings"], n, e.get("earnings")),
                        ts,
                        district,
                    ),
                )

            elif kind == "collection_deposit":
                cid = int(e.get("collectionId") or 0)
                if cid:
                    row = con.execute("SELECT * FROM collection_stats WHERE collection_id=?", (cid,)).fetchone()
                    if row is None:
                        con.execute(
                            "INSERT INTO collection_stats(collection_id,name,updated_at) VALUES(?,?,?)",
                            (cid, str(e.get("collectionName") or ""), ts),
                        )
                        row = con.execute("SELECT * FROM collection_stats WHERE collection_id=?", (cid,)).fetchone()

                    con.execute(
                        """
                        UPDATE collection_stats
                        SET name=?,deposits=?,deposited_value=?,updated_at=?
                        WHERE collection_id=?
                        """,
                        (
                            str(e.get("collectionName") or row["name"] or ""),
                            int(row["deposits"]) + 1,
                            float(row["deposited_value"] or 0) + float(e.get("value") or 0),
                            ts,
                            cid,
                        ),
                    )

            ack.append(event_id)

    return ack


# ----------------------------------------------------------------------
# MENELMODE RESULT
# ----------------------------------------------------------------------
def menel_result_object(status: dict[str, Any] | None) -> tuple[dict[str, Any] | None, str]:
    """Return the same MenelMode result regardless of which API field exposed it.

    The game sometimes publishes a finished run as lastMenelModeResult and
    sometimes only through character.pending_activity_result. The userscript
    normalizes the latter into learningResult so learning never depends on the
    UI/status race.
    """
    if not isinstance(status, dict):
        return None, ""

    for field in ("lastMenelModeResult", "learningResult", "pendingResult"):
        raw = status.get(field)
        if isinstance(raw, str):
            try:
                raw = json.loads(raw)
            except Exception:
                raw = None
        if not isinstance(raw, dict):
            continue

        # tolerate wrappers from pending_activity_result
        if not any(k in raw for k in ("collecting", "begging", "dumpster")):
            inner = raw.get("result") or raw.get("results")
            if isinstance(inner, dict):
                raw = inner

        if any(k in raw for k in ("collecting", "begging", "dumpster")):
            return raw, field

    return None, ""


def parse_menel_result(status: dict[str, Any] | None) -> dict[str, float] | None:
    result, _source = menel_result_object(status)
    if not result:
        return None

    collecting = result.get("collecting") or {}
    begging = result.get("begging") or {}
    dumpster = result.get("dumpster") or {}

    cans = float(collecting.get("collected") or collecting.get("total") or 0)
    cash = float(begging.get("netEarnings") or begging.get("earned") or 0)

    item_value = 0.0
    item = dumpster.get("item") or {}
    if isinstance(item, dict):
        item_value += float(item.get("sell_price_paser") or item.get("paserSellPrice") or 0)

    bonus = dumpster.get("bonusItem") or {}
    if isinstance(bonus, dict):
        item_value += float(bonus.get("sell_price_paser") or bonus.get("paserSellPrice") or 0)

    can_value = float(CFG["menel_mode"].get("can_value_pln", 0.12))
    reward = cash + item_value + cans * can_value
    duration = float(status.get("learningEstimatedDuration") or status.get("estimatedDuration") or 0)

    return {
        "cans": cans,
        "cash": cash,
        "item_value": item_value,
        "reward": reward,
        "duration": duration,
    }


def ingest_menel_result(status: dict[str, Any] | None) -> bool:
    parsed = parse_menel_result(status)
    if not parsed:
        return False

    result_obj, result_source = menel_result_object(status)
    district = str(status.get("learningDistrictName") or status.get("districtName") or "?")
    key = "menel:" + stable_key({"district": district, "result": result_obj})
    now = int(time.time() * 1000)

    with LOCK, db() as con:
        if not claim_event(con, key, now, "menel_result"):
            return False

        row = con.execute("SELECT * FROM menel_stats WHERE district=?", (district,)).fetchone()

        if row is None:
            con.execute(
                """
                INSERT INTO menel_stats(
                  district,runs,mean_reward,mean_cash,mean_cans,mean_item_value,mean_duration,updated_at
                ) VALUES(?,?,?,?,?,?,?,?)
                """,
                (
                    district, 1,
                    parsed["reward"], parsed["cash"], parsed["cans"],
                    parsed["item_value"], parsed["duration"], now
                ),
            )
        else:
            n = int(row["runs"])
            con.execute(
                """
                UPDATE menel_stats
                SET runs=?,mean_reward=?,mean_cash=?,mean_cans=?,
                    mean_item_value=?,mean_duration=?,updated_at=?
                WHERE district=?
                """,
                (
                    n + 1,
                    mean_update(row["mean_reward"], n, parsed["reward"]),
                    mean_update(row["mean_cash"], n, parsed["cash"]),
                    mean_update(row["mean_cans"], n, parsed["cans"]),
                    mean_update(row["mean_item_value"], n, parsed["item_value"]),
                    mean_update(row["mean_duration"], n, parsed["duration"]),
                    now,
                    district,
                ),
            )

    log(f"MenelMode learned: {district} reward≈{parsed['reward']:.2f} zł • source={result_source or 'unknown'}")
    return True


# ----------------------------------------------------------------------
# RAID OBSERVATION (read-only recommendation)
# ----------------------------------------------------------------------
def ingest_raid(world: dict[str, Any]) -> None:
    active = ((world.get("activeRaid") or {}).get("activePlan") or {})
    if not active:
        return

    lid = int(active.get("raid_location_id") or 0)
    if not lid:
        return

    status = str(active.get("status") or "")
    key = "raid:" + stable_key({
        "id": active.get("id"),
        "status": status,
        "money": active.get("money_gained"),
        "success": active.get("was_successful"),
    })

    now = int(time.time() * 1000)

    with LOCK, db() as con:
        if not claim_event(con, key, now, "raid_observation"):
            return

        row = con.execute("SELECT * FROM raid_stats WHERE location_id=?", (lid,)).fetchone()
        if row is None:
            con.execute(
                "INSERT INTO raid_stats(location_id,name,updated_at) VALUES(?,?,?)",
                (lid, str(active.get("location_name") or ""), now),
            )
            row = con.execute("SELECT * FROM raid_stats WHERE location_id=?", (lid,)).fetchone()

        obs = int(row["observations"])
        completed = int(row["completed"])
        done = status in {"completed", "finished", "success", "failed"} or active.get("was_successful") is not None

        if done:
            duration = float(active.get("raid_duration_minutes") or 0)
            money = float(active.get("money_gained") or 0)
            con.execute(
                """
                UPDATE raid_stats
                SET name=?,observations=?,completed=?,successes=?,
                    mean_money=?,mean_duration_minutes=?,updated_at=?
                WHERE location_id=?
                """,
                (
                    str(active.get("location_name") or row["name"] or ""),
                    obs + 1,
                    completed + 1,
                    int(row["successes"]) + (1 if active.get("was_successful") else 0),
                    mean_update(row["mean_money"], completed, money),
                    mean_update(row["mean_duration_minutes"], completed, duration),
                    now,
                    lid,
                ),
            )
        else:
            con.execute(
                "UPDATE raid_stats SET name=?,observations=?,updated_at=? WHERE location_id=?",
                (str(active.get("location_name") or row["name"] or ""), obs + 1, now, lid),
            )


# ----------------------------------------------------------------------
# WORLD SNAPSHOT
# ----------------------------------------------------------------------
def save_world_snapshot(payload: dict[str, Any]) -> None:
    ch = payload.get("character") or {}
    now = int(payload.get("now") or time.time() * 1000)

    with LOCK, db() as con:
        last = con.execute("SELECT MAX(ts) ts FROM world_snapshots").fetchone()["ts"]
        if last and now - int(last) < 60_000:
            return

        compact = {
            "resources": payload.get("resources"),
            "modules": payload.get("modules"),
            "queue": payload.get("queue"),
            "activeListings": payload.get("activeListings"),
        }

        con.execute(
            """
            INSERT INTO world_snapshots(ts,district,money,cans,energy,payload_json)
            VALUES(?,?,?,?,?,?)
            """,
            (
                now,
                str(ch.get("districtName") or ""),
                float(ch.get("money") or 0),
                float(ch.get("cans") or 0),
                float(ch.get("energy") or 0),
                json.dumps(compact, ensure_ascii=False, separators=(",", ":")),
            ),
        )

        # 30 dni przy 1 próbce/min to ~43k wierszy; starsze wycinamy.
        con.execute("DELETE FROM world_snapshots WHERE ts < ?", (now - 30 * 24 * 3600 * 1000,))


# ----------------------------------------------------------------------
# ECONOMY
# ----------------------------------------------------------------------
def choose_recipe(candidates: list[dict[str, Any]]) -> tuple[dict[str, Any] | None, list[dict[str, Any]]]:
    if not candidates:
        return None, []

    with db() as con:
        total_outcomes = con.execute(
            "SELECT COALESCE(SUM(sold+returned),0) AS n FROM recipe_stats"
        ).fetchone()["n"]

        scored = []
        prior_strength = max(0.5, float(CFG.get("recipe_prior_strength", 4.0)))
        explore_strength = max(0.0, float(CFG.get("exploration_strength", 0.08)))
        return_penalty = max(0.0, min(0.9, float(CFG.get("return_penalty", 0.22))))
        max_adj = max(0.0, min(0.9, float(CFG.get("max_recipe_adjustment", 0.40))))

        for c in candidates:
            rid = int(c.get("recipeId") or 0)
            prior = float(c.get("localLearningScore") or c.get("profitHour") or 0)
            if prior <= 0:
                continue

            r = con.execute("SELECT * FROM recipe_stats WHERE recipe_id=?", (rid,)).fetchone()
            if r:
                sold = int(r["sold"])
                returned = int(r["returned"])
                n = sold + returned
                real_ph = r["mean_profit_hour"]
            else:
                sold = returned = n = 0
                real_ph = None

            if real_ph is not None and math.isfinite(float(real_ph)):
                blend = (prior * prior_strength + float(real_ph) * n) / (prior_strength + n)
            else:
                blend = prior

            success = (sold + 3.0) / (sold + returned + 4.0)
            sell_factor = 1.0 - (1.0 - success) * return_penalty

            exploration = (
                prior * explore_strength *
                math.sqrt(max(0.0, math.log(float(total_outcomes) + 2.0)) / (n + 1.0))
            )

            raw_score = blend * sell_factor + exploration
            low = prior * (1.0 - max_adj)
            high = prior * (1.0 + max_adj)
            score = max(low, min(high, raw_score))

            scored.append({
                **c,
                "brainScore": score,
                "brainSamples": n,
                "brainSold": sold,
                "brainReturned": returned,
                "brainSuccess": success,
                "brainHistoricalProfitHour": real_ph,
                "explorationBonus": exploration,
            })

        scored.sort(key=lambda x: (x["brainScore"], x.get("profit", 0)), reverse=True)
        return (scored[0] if scored else None), scored


# ----------------------------------------------------------------------
# HUSTLING
# ----------------------------------------------------------------------
def hustle_expected(row: dict[str, Any], status: dict[str, Any]) -> float:
    low = float(row.get("minEarningPerHour") or 0)
    high = float(row.get("maxEarningPerHour") or 0)
    base = (low + high) / 2.0

    skill = float(status.get("skillBonus") or 0)
    buff = float(status.get("buffBonus") or 0)
    equipment = row.get("equipment") or {}
    eq = float(equipment.get("earningsBonus") or 0)

    mathematical = base * (1.0 + (skill + buff + eq) / 100.0)

    tid = int(row.get("id") or 0)
    with db() as con:
        learned = con.execute("SELECT * FROM hustling_stats WHERE type_id=?", (tid,)).fetchone()

    if learned and learned["mean_earnings_hour"] is not None:
        n = int(learned["runs"])
        w = n / (n + 3.0)
        mathematical = mathematical * (1.0 - w) + float(learned["mean_earnings_hour"]) * w

    return mathematical


def best_hustle(status: dict[str, Any]) -> dict[str, Any] | None:
    rows = []
    for t in status.get("types") or []:
        if t.get("locked") or t.get("canStart") is False:
            # API nie zawsze daje canStart per typ; brak pola nie blokuje.
            if "canStart" in t:
                continue
        score = hustle_expected(t, status)
        rows.append({**t, "brainExpectedHour": score})

    rows.sort(key=lambda x: x["brainExpectedHour"], reverse=True)
    return rows[0] if rows else None


# ----------------------------------------------------------------------
# NPC
# ----------------------------------------------------------------------
def choose_npc(payload: dict[str, Any]) -> dict[str, Any] | None:
    world = payload.get("world") or {}
    npc_list = (world.get("npcList") or {}).get("npcs") or []
    npc_status = world.get("npcStatus") or {}
    reserve = float((payload.get("limits") or {}).get("npcEnergyReserve") or 0)

    energy_now = float(
        npc_status.get("energy")
        or (payload.get("character") or {}).get("energy")
        or 0
    )

    if not npc_status.get("canStartAttack", True):
        return None

    if (npc_status.get("returnCooldown") or {}).get("active"):
        return None

    own_cooldowns = {
        int(x.get("npcId") or 0)
        for x in (npc_status.get("npcCooldowns") or [])
        if int(x.get("npcId") or 0) and float(x.get("remainingMs") or 0) > 0
    }

    player_attack = float(npc_status.get("playerAttack") or 0)
    favor_red = float((npc_status.get("favorBonuses") or {}).get("menelpowerReduction") or 0)
    buff_red = float((npc_status.get("buffBonuses") or {}).get("menelpowerReduction") or 0)
    reduction = favor_red + buff_red

    scored = []

    with db() as con:
        for npc in npc_list:
            nid = int(npc.get("id") or 0)
            if not nid:
                continue
            if nid in own_cooldowns:
                continue

            defense = float(npc.get("defense") or 0)

            # Jeśli enriched API zwraca flagi, respektujemy jawne false.
            # Brak pola w aktualnym /npcs NIE oznacza false.
            if "canAttack" in npc and npc.get("canAttack") is False:
                continue
            if "hasEnoughEnergy" in npc and npc.get("hasEnoughEnergy") is False:
                continue

            if player_attack > 0 and defense > player_attack:
                continue

            explicit_cost = npc.get("effectiveEnergyCost")
            if explicit_cost is not None:
                cost = max(1.0, float(explicit_cost))
            else:
                cost = max(1.0, defense - reduction)

            if energy_now < cost:
                continue
            if energy_now - cost < reserve:
                continue

            mid_money = (
                float(npc.get("money_min") or 0)
                + float(npc.get("money_max") or 0)
            ) / 2.0

            learned = con.execute(
                "SELECT * FROM npc_stats WHERE npc_id=?",
                (nid,)
            ).fetchone()

            if learned and learned["mean_reward"] is not None:
                n = int(learned["attacks"])
                w = n / (n + 3.0)
                reward = mid_money * (1.0 - w) + float(learned["mean_reward"]) * w
            else:
                reward = mid_money

            score = reward / cost
            attacks = int(learned["attacks"]) if learned else 0
            score *= 1.0 + 0.08 / math.sqrt(attacks + 1.0)

            scored.append({
                **npc,
                "effectiveEnergyCost": cost,
                "brainReward": reward,
                "brainScore": score
            })

    scored.sort(
        key=lambda x: (x["brainScore"], x["brainReward"]),
        reverse=True
    )
    return scored[0] if scored else None


# ----------------------------------------------------------------------
# COLLECTION
# ----------------------------------------------------------------------
def collection_candidate(payload: dict[str, Any]) -> dict[str, Any] | None:
    if not (payload.get("modules") or {}).get("collections"):
        return None

    world = payload.get("world") or {}
    tiers = (world.get("collections") or {}).get("tiers") or []
    values = {str(k): v for k, v in (payload.get("itemValues") or {}).items()}
    limit = float((payload.get("limits") or {}).get("collectionMaxItemValue") or 0)

    candidates = []

    for tier in tiers:
        for col in tier.get("collections") or []:
            if col.get("isCompleted") and not col.get("isRepeatable"):
                continue

            missing = [
                x for x in (col.get("requiredItems") or [])
                if float(x.get("deposited") or 0) < float(x.get("required") or 0)
            ]

            for req in missing:
                if float(req.get("owned") or 0) <= 0:
                    continue

                item_id = int(req.get("itemId") or 0)
                value = values.get(str(item_id))
                if value is None:
                    continue
                value = float(value)
                if value > limit:
                    continue

                reward_score = float(col.get("rewardMoney") or 0) + float(col.get("rewardGoldenTeeth") or 0) * 100.0
                progress = sum(
                    min(float(x.get("required") or 0), float(x.get("deposited") or 0))
                    for x in (col.get("requiredItems") or [])
                )
                required_total = sum(float(x.get("required") or 0) for x in (col.get("requiredItems") or [])) or 1.0
                completion = progress / required_total

                score = reward_score * (0.4 + completion) - value
                candidates.append({
                    "collectionId": int(col.get("id") or 0),
                    "collectionName": str(col.get("name") or ""),
                    "itemId": item_id,
                    "itemName": str(req.get("name") or ""),
                    "value": value,
                    "score": score,
                })

    candidates.sort(key=lambda x: x["score"], reverse=True)
    return candidates[0] if candidates else None


# ----------------------------------------------------------------------
# FAVORS — only cheap cards and only when they may unlock an NPC
# ----------------------------------------------------------------------
def favor_candidate(payload: dict[str, Any]) -> dict[str, Any] | None:
    if not (payload.get("modules") or {}).get("favors"):
        return None

    world = payload.get("world") or {}
    if (world.get("favorActive") or {}).get("active"):
        return None

    owned = (world.get("favorOwned") or {}).get("favors") or []
    npcs = (world.get("npcList") or {}).get("npcs") or []
    max_value = float((payload.get("limits") or {}).get("favorMaxPremiumValue") or 0)

    # Jeśli już mamy legalny cel NPC, nie marnujemy karty.
    if any(x.get("canAttack") and x.get("hasEnoughEnergy") for x in npcs):
        return None

    cards = []
    for card in owned:
        price = float(card.get("premium_price") or 1e9)
        if price > max_value:
            continue

        attack_bonus = 0.0
        energy_reduction = 0.0
        for m in card.get("modifiers") or []:
            if m.get("modifier_type") == "npc_attack_attack":
                attack_bonus += float(m.get("value_flat") or 0)
            if m.get("modifier_type") == "npc_attack_menelpower_reduction":
                energy_reduction += float(m.get("value_flat") or 0)

        if attack_bonus <= 0 and energy_reduction <= 0:
            continue

        # Heurystyka: tania karta z większym wpływem jest lepsza.
        utility = (attack_bonus + energy_reduction * 0.8) / max(1.0, price)
        cards.append({**card, "brainUtility": utility})

    cards.sort(key=lambda x: x["brainUtility"], reverse=True)
    return cards[0] if cards else None


# ----------------------------------------------------------------------
# DISTRICT SWEEP — WHITE -> RED -> HUSTLE
# ----------------------------------------------------------------------
def cooldown_row_active(row: Any) -> bool:
    if not isinstance(row, dict):
        return False
    return any(float(row.get(k) or 0) > 0 for k in ("scavenging","dumpster","begging"))


def district_available_now(all_cooldowns: dict[str,Any], district_id: int) -> bool:
    rows=(all_cooldowns or {}).get("cooldowns") or {}
    return not cooldown_row_active(rows.get(str(int(district_id))))


def district_sweep_state(payload: dict[str,Any], *, create: bool = True) -> dict[str,Any]:
    global LAST_DISTRICT_SWEEP

    modules=payload.get("modules") or {}
    world=payload.get("world") or {}
    tt=world.get("travelTimes") or {}
    districts=tt.get("districts") or []
    all_cd=world.get("allCooldowns") or {}
    now=int(time.time()*1000)

    if not modules.get("districtSweep"):
        state={
            "enabled":False,"phase":"OFF","reason":"wyłączone w ustawieniach",
            "total":0,"completed":0,"remaining":0,"remainingIds":[],"remainingNames":[]
        }
        LAST_DISTRICT_SWEEP=state
        return state

    if not districts:
        state={
            "enabled":True,"phase":"WAIT_TRAVEL_DATA",
            "reason":"brak listy dzielnic/travelTimes",
            "total":0,"completed":0,"remaining":0,"remainingIds":[],"remainingNames":[]
        }
        LAST_DISTRICT_SWEEP=state
        return state

    if not all_cd.get("success"):
        state={
            "enabled":True,"phase":"WAIT_COOLDOWNS",
            "reason":str(world.get("allCooldownsError") or "brak /all-cooldowns"),
            "source":str(world.get("allCooldownsSource") or "BRAK"),
            "total":0,"completed":0,"remaining":0,"remainingIds":[],"remainingNames":[]
        }
        LAST_DISTRICT_SWEEP=state
        return state

    by_id={int(d.get("id") or 0):d for d in districts if int(d.get("id") or 0)}
    saved=meta_get_json("district_sweep_v1",None)
    current_white=[did for did in by_id if district_available_now(all_cd,did)]

    # v3.2.4 SWEEP REARM FIX:
    # Faza HUSTLE nie jest już stanem „ślepym” aż do planowego końca kombinowania.
    # Jeżeli podczas/po HUSTLE pojawi się choć jedna ponownie biała dzielnica,
    # natychmiast otwieramy NOWY snapshot sweepu. choose_world_action() ma twardy
    # priorytet SWEEP i, gdy Kombinowanie jest aktywne, zwróci hustle_stop.
    # Dzięki temu wygasły cooldown MenelMode zawsze wygrywa z dalszym hustlingiem.
    if isinstance(saved,dict) and str(saved.get("phase") or "").lower()=="hustle" and current_white:
        previous_started=int(saved.get("startedAt") or 0)
        previous_completed=int(saved.get("completedAt") or 0)
        saved={
            "version":2,
            "phase":"sweep",
            "startedAt":now,
            "targets":list(current_white),
            "completed":[],
            "completedAt":0,
            "rearmedAt":now,
            "rearmReason":"pojawiły się białe dzielnice podczas/po HUSTLE",
            "previousStartedAt":previous_started,
            "previousCompletedAt":previous_completed,
            "npcAttemptedAfterSweep":False
        }
        meta_set_json("district_sweep_v1",saved)

    if not isinstance(saved,dict) and create:
        white=list(current_white)
        saved={
            "version":1,
            "phase":"sweep" if white else "hustle",
            "startedAt":now,
            "targets":white,
            "completed":[],
            "completedAt":0 if white else now
        }
        meta_set_json("district_sweep_v1",saved)

    if not isinstance(saved,dict):
        state={"enabled":True,"phase":"UNKNOWN","total":0,"completed":0,"remaining":0,"remainingIds":[],"remainingNames":[]}
        LAST_DISTRICT_SWEEP=state
        return state

    targets=[int(x) for x in saved.get("targets") or [] if int(x) in by_id]
    completed={int(x) for x in saved.get("completed") or [] if int(x) in by_id}
    started_at=int(saved.get("startedAt") or now)

    for did in targets:
        if not district_available_now(all_cd,did):
            completed.add(did)

    current_id=int(
        (payload.get("character") or {}).get("currentDistrictId")
        or (world.get("travelStatus") or {}).get("currentDistrictId")
        or 0
    )
    menel_status=world.get("menel") or {}
    current_cd=menel_status.get("cooldowns") or {}
    current_has_cd=any(
        float((current_cd.get(k) or {}).get("timeRemaining") or 0) > 0
        for k in ("collecting","begging","dumpster")
    )
    if current_id in targets and menel_status.get("canStart") is False and current_has_cd:
        completed.add(current_id)

    with db() as con:
        rows=con.execute(
            "SELECT district,updated_at FROM menel_stats WHERE updated_at>=?",
            (started_at,)
        ).fetchall()
    recent_names={str(r["district"]) for r in rows}
    for did in targets:
        if str(by_id[did].get("name") or "") in recent_names:
            completed.add(did)

    phase=str(saved.get("phase") or "sweep")
    remaining=[did for did in targets if did not in completed]

    if phase=="sweep" and not remaining:
        phase="hustle"
        saved["phase"]="hustle"
        saved["completedAt"]=now

    saved["completed"]=sorted(completed)
    meta_set_json("district_sweep_v1",saved)

    state={
        "enabled":True,
        "phase":phase.upper(),
        "startedAt":started_at,
        "total":len(targets),
        "completed":len(completed),
        "remaining":len(remaining),
        "remainingIds":remaining,
        "remainingNames":[str(by_id[x].get("name") or x) for x in remaining],
        "targetIds":targets,
        "currentWhiteIds":list(current_white),
        "canMaxKnown":0.15,
        "source":str(world.get("allCooldownsSource") or "UNKNOWN"),
        "reason":str(saved.get("rearmReason") or "")
    }
    LAST_DISTRICT_SWEEP=state
    return state


def choose_sweep_target(payload: dict[str,Any], sweep: dict[str,Any]) -> dict[str,Any] | None:
    world=payload.get("world") or {}
    ch=payload.get("character") or {}
    limits=payload.get("limits") or {}
    districts=(world.get("travelTimes") or {}).get("districts") or []

    current_id=int(ch.get("currentDistrictId") or 0)
    cans=float(ch.get("cans") or 0)
    sell_min=float(limits.get("sellCansMin") or 0)
    target_price=float(limits.get("canTargetPrice") or 0.15)
    remaining=set(int(x) for x in sweep.get("remainingIds") or [])

    options=[d for d in districts if int(d.get("id") or 0) in remaining and int(d.get("id") or 0)!=current_id]
    if not options:
        return None

    max_price_opts=[
        d for d in options
        if cans>=sell_min and float(d.get("canPrice") or 0)>=target_price-1e-9
    ]
    pool=max_price_opts or options
    pool.sort(key=lambda d:(float(d.get("travelTime") or 999999),-float(d.get("canPrice") or 0),int(d.get("id") or 0)))
    return pool[0] if pool else None


# ----------------------------------------------------------------------
# DISTRICT / CANS / TRAVEL
# ----------------------------------------------------------------------
def travel_or_can_action(payload: dict[str, Any]) -> dict[str, Any] | None:
    modules=payload.get("modules") or {}
    world=payload.get("world") or {}
    ch=payload.get("character") or {}
    limits=payload.get("limits") or {}

    cans=float(ch.get("cans") or 0)
    sell_min=float(limits.get("sellCansMin") or 0)
    current_id=int(ch.get("currentDistrictId") or 0)
    current_name=str(ch.get("districtName") or "")
    target_price=min(0.15,max(0.01,float(limits.get("canTargetPrice") or 0.15)))

    tt=world.get("travelTimes") or {}
    districts=tt.get("districts") or []
    current_price=float((tt.get("currentDistrict") or {}).get("canPrice") or 0)

    if modules.get("cans") and cans>=sell_min and current_price>=target_price-1e-9:
        return {
            "type":"sell_cans","cans":int(cans),
            "label":f"Sprzedaj {int(cans)} puszek po {current_price:.2f} zł",
            "reason":f"Osiągnięta docelowa cena {target_price:.2f} zł (maks. znany 0.15 zł)",
            "utility":cans*current_price
        }

    if modules.get("travel") and modules.get("cans") and cans>=sell_min:
        target_rows=[
            d for d in districts
            if float(d.get("canPrice") or 0)>=target_price-1e-9
            and int(d.get("id") or 0)!=current_id
        ]
        if target_rows:
            target=min(target_rows,key=lambda d:float(d.get("travelTime") or 999999))
            return {
                "type":"travel","districtId":int(target.get("id") or 0),
                "districtName":str(target.get("name") or ""),
                "label":f"Jedź sprzedać puszki po {float(target.get('canPrice') or 0):.2f} zł: {target.get('name')}",
                "reason":f"Cel puszek {target_price:.2f} zł; obecnie {current_price:.2f} zł",
                "utility":max(1.0,cans*(float(target.get("canPrice") or 0)-current_price))
            }

    if modules.get("travel") and bool(limits.get("exploreDistricts")) and not modules.get("districtSweep"):
        menel=world.get("menel") or {}
        if menel.get("canStart"):
            with db() as con:
                stats={r["district"]:int(r["runs"]) for r in con.execute("SELECT district,runs FROM menel_stats")}
            current_runs=stats.get(current_name,0)
            untested=[d for d in districts if stats.get(str(d.get("name") or ""),0)==0 and int(d.get("id") or 0)!=current_id]
            chance=float(CFG.get("district_exploration_chance",0.12))
            if current_runs>=1 and untested and random.random()<chance:
                target=min(untested,key=lambda x:float(x.get("travelTime") or 999999))
                return {
                    "type":"travel","districtId":int(target.get("id") or 0),"districtName":str(target.get("name") or ""),
                    "label":f"Eksploruj dzielnicę: {target.get('name')}",
                    "reason":"AI zbiera pierwszą próbkę MenelMode dla niepoznanej dzielnicy","utility":1.0
                }
    return None


# ----------------------------------------------------------------------
# RAID RECOMMENDATION — no write endpoint was captured, so read-only.
# ----------------------------------------------------------------------
def raid_recommendation(payload: dict[str, Any]) -> str:
    world = payload.get("world") or {}
    rows = (world.get("raidLocations") or {}).get("locations") or []
    if not rows:
        return "brak danych"

    with db() as con:
        learned = {
            int(r["location_id"]): r
            for r in con.execute("SELECT * FROM raid_stats")
        }

    scored = []
    for r in rows:
        if float(r.get("cooldown_remaining") or 0) > 0:
            continue

        lid = int(r.get("id") or 0)
        mid_money = (float(r.get("money_min") or 0) + float(r.get("money_max") or 0)) / 2.0
        dur = max(1.0, float(r.get("raid_duration_minutes") or 1))
        stat = learned.get(lid)

        if stat and stat["mean_money"] is not None and int(stat["completed"]) > 0:
            money = float(stat["mean_money"])
            success = (int(stat["successes"]) + 2.0) / (int(stat["completed"]) + 3.0)
        else:
            money = mid_money
            success = 0.67

        score = money * success / dur
        # Loot nie jest jeszcze kompletnie wyceniony, więc nie udajemy pełnego EV.
        scored.append((score, r, stat))

    if not scored:
        return "wszystkie cele na cooldownie"

    scored.sort(key=lambda x: x[0], reverse=True)
    score, row, stat = scored[0]
    suffix = f" • {int(stat['completed'])} własnych wyników" if stat else " • heurystyka, brak własnych wyników"
    return f"{row.get('name')} • score gotówki/czas {score:.2f}{suffix}"


# ----------------------------------------------------------------------
# TASK HINTS
# ----------------------------------------------------------------------
def task_hint(payload: dict[str, Any]) -> str:
    world = payload.get("world") or {}
    daily = world.get("dailyTasks") or {}
    weekly = world.get("weeklyTasks") or {}

    def count_open(obj: Any) -> int:
        if not isinstance(obj, dict):
            return 0
        for key in ("tasks", "daily", "weekly"):
            if isinstance(obj.get(key), list):
                return sum(1 for t in obj[key] if not t.get("completed") and not t.get("isCompleted"))
        return 0

    d = count_open(daily)
    w = count_open(weekly)
    if not d and not w:
        return "brak otwartych zadań wykrytych"
    return f"otwarte: dzienne {d} • tygodniowe {w}"


# ----------------------------------------------------------------------
# LOCAL LLM REVIEWER (OLLAMA, OPTIONAL)
# ----------------------------------------------------------------------
def ollama_request(path: str, payload: dict[str,Any]|None=None, timeout: float=10.0) -> dict[str,Any]:
    cfg=CFG.get("local_llm") or {}
    base=str(cfg.get("base_url") or "http://127.0.0.1:11434").rstrip("/")
    data=None if payload is None else json.dumps(payload,ensure_ascii=False).encode("utf-8")
    req=urllib.request.Request(base+path,data=data,headers={"Content-Type":"application/json"},method="GET" if payload is None else "POST")
    with urllib.request.urlopen(req,timeout=timeout) as r:
        return json.loads(r.read().decode("utf-8"))


def local_llm_model() -> str:
    cfg=CFG.get("local_llm") or {}
    configured=str(cfg.get("model") or "").strip()
    if configured: return configured
    try:
        tags=ollama_request("/api/tags",timeout=3)
        models=tags.get("models") or []
        if models: return str(models[0].get("name") or models[0].get("model") or "")
    except Exception:
        pass
    return ""


def local_llm_review(candidates: list[dict[str,Any]], context: dict[str,Any]) -> tuple[str|None,str]:
    global LAST_LLM_REVIEW_AT,LAST_LLM_STATUS,LAST_LLM_PICK
    cfg=CFG.get("local_llm") or {}
    if not cfg.get("enabled",True):
        LAST_LLM_STATUS={"status":"OFF","model":"","last_error":"","last_review":LAST_LLM_REVIEW_AT}
        return None,"LLM OFF"
    if not candidates: return None,"brak kandydatów"
    interval=max(30.0,float(cfg.get("review_interval_seconds") or 180))
    if time.time()-LAST_LLM_REVIEW_AT<interval and LAST_LLM_PICK:
        valid={str(x.get("candidateId")) for x in candidates}
        if str(LAST_LLM_PICK) in valid: return str(LAST_LLM_PICK),"cache lokalnego LLM"
    model=local_llm_model()
    if not model:
        LAST_LLM_STATUS={"status":"BRAK MODELU","model":"","last_error":"Ollama niedostępna albo brak modelu","last_review":LAST_LLM_REVIEW_AT}
        return None,"brak modelu"
    compact=[{"id":x.get("candidateId"),"label":x.get("label"),"group":x.get("group"),"score":round(float(x.get("adjustedScore") or 0),3),"confidence":round(float(x.get("confidence") or 0),3),"reason":x.get("reason")} for x in candidates[:8]]
    prompt={"objective":"Wybierz najlepszą długoterminowo akcję. Nie wymyślaj nowych działań.","rules":["wybierz wyłącznie id z candidates","maksymalizuj długoterminową wartość i uczenie","nie obchodź zabezpieczeń","zwróć tylko JSON {id,reason}"],"context":context,"candidates":compact}
    try:
        resp=ollama_request("/api/chat",{"model":model,"stream":False,"format":"json","messages":[{"role":"system","content":"Jesteś lokalnym recenzentem. Wybierasz tylko ID z listy."},{"role":"user","content":json.dumps(prompt,ensure_ascii=False)}],"options":{"temperature":0.15}},timeout=max(5.0,float(cfg.get("timeout_seconds") or 18)))
        obj=json.loads(str((resp.get("message") or {}).get("content") or "{}"))
        pick=str(obj.get("id") or "")
        valid={str(x.get("candidateId")) for x in candidates}
        if pick not in valid: raise ValueError("ID spoza listy")
        LAST_LLM_REVIEW_AT=time.time(); LAST_LLM_PICK=pick
        LAST_LLM_STATUS={"status":"ONLINE","model":model,"last_error":"","last_review":LAST_LLM_REVIEW_AT}
        note=str(obj.get("reason") or "lokalny LLM")[:500]
        with db() as con:
            con.execute("INSERT INTO policy_reflections(ts,source,selected_action_key,note) VALUES(?,?,?,?)",(int(time.time()*1000),"local_llm",pick,note))
        return pick,note
    except Exception as e:
        LAST_LLM_STATUS={"status":"BŁĄD","model":model,"last_error":f"{type(e).__name__}: {e}","last_review":LAST_LLM_REVIEW_AT}
        return None,f"LLM error: {type(e).__name__}"

# ----------------------------------------------------------------------
# LOCAL LLM — RECENZJA EKONOMII / RECEPTUR
# ----------------------------------------------------------------------
def local_llm_review_recipes(scored: list[dict[str, Any]], payload: dict[str, Any]) -> tuple[dict[str, Any] | None, str]:
    global LAST_RECIPE_LLM_REVIEW_AT, LAST_RECIPE_LLM_PICK, LAST_RECIPE_LLM_NOTE
    global LAST_LLM_STATUS

    cfg = CFG.get("local_llm") or {}
    if not cfg.get("enabled", True):
        LAST_LLM_STATUS={"status":"OFF","model":"","last_error":"","last_review":LAST_LLM_STATUS.get("last_review",0)}
        return None, "lokalny LLM wyłączony"
    if not scored:
        return None, "brak bezpiecznych receptur"

    model = local_llm_model()
    if not model:
        LAST_LLM_STATUS={"status":"BRAK MODELU","model":"","last_error":"Ollama niedostępna albo brak modelu","last_review":LAST_LLM_STATUS.get("last_review",0)}
        return None, "brak lokalnego modelu"

    if len(scored)==1:
        LAST_LLM_STATUS={"status":"READY","model":model,"last_error":"","last_review":LAST_LLM_STATUS.get("last_review",0)}
        return scored[0], "tylko jedna bezpieczna receptura"

    interval=max(30.0,float(cfg.get("review_interval_seconds") or 180))
    valid_ids={f"recipe:{int(x.get('recipeId') or 0)}" for x in scored}
    if time.time()-LAST_RECIPE_LLM_REVIEW_AT<interval and LAST_RECIPE_LLM_PICK and str(LAST_RECIPE_LLM_PICK) in valid_ids:
        rid=int(str(LAST_RECIPE_LLM_PICK).split(':',1)[1])
        picked=next((x for x in scored if int(x.get('recipeId') or 0)==rid),None)
        if picked:
            LAST_LLM_STATUS={"status":"ONLINE","model":model,"last_error":"","last_review":LAST_RECIPE_LLM_REVIEW_AT}
            return picked,"cache LLM: "+(LAST_RECIPE_LLM_NOTE or "recenzja ekonomii")

    compact=[]
    for x in scored[:8]:
        compact.append({
            "id":f"recipe:{int(x.get('recipeId') or 0)}",
            "name":str(x.get("name") or ""),
            "brainScore":round(float(x.get("brainScore") or 0),2),
            "profit":round(float(x.get("profit") or 0),2),
            "profitHour":round(float(x.get("profitHour") or 0),2),
            "cashProfit":round(float(x.get("cashProfit") or 0),2),
            "cashProfitHour":round(float(x.get("cashProfitHour") or 0),2),
            "samples":int(x.get("brainSamples") or 0),
            "sold":int(x.get("brainSold") or 0),
            "returned":int(x.get("brainReturned") or 0),
            "sellSuccessPct":round(float(x.get("brainSuccess") or 0)*100,1),
            "historicalProfitHour":x.get("brainHistoricalProfitHour")
        })

    prompt={
        "objective":"Wybierz najlepszą recepturę do długoterminowego zarobku.",
        "rules":[
            "wybierz wyłącznie jedno id z recipes",
            "nie wymyślaj receptur ani akcji",
            "uwzględnij zysk/h, realne wyniki, skuteczność sprzedaży i liczbę próbek",
            "jeżeli wyniki są podobne, możesz preferować mniej zbadaną recepturę dla zdobycia wiedzy",
            "zwróć WYŁĄCZNIE JSON {\\\"id\\\":\\\"recipe:...\\\",\\\"reason\\\":\\\"...\\\"}"
        ],
        "character":{
            "money":(payload.get("character") or {}).get("money"),
            "district":(payload.get("character") or {}).get("districtName")
        },
        "recipes":compact
    }
    try:
        resp=ollama_request('/api/chat',{
            "model":model,"stream":False,"format":"json",
            "messages":[
                {"role":"system","content":"Jesteś lokalnym recenzentem ekonomii. Nie wykonujesz żadnych akcji. Wybierasz wyłącznie ID receptury z podanej listy."},
                {"role":"user","content":json.dumps(prompt,ensure_ascii=False)}
            ],
            "options":{"temperature":0.10}
        },timeout=max(5.0,float(cfg.get("timeout_seconds") or 18)))
        content=str((resp.get("message") or {}).get("content") or '{}')
        obj=json.loads(content)
        pick=str(obj.get("id") or '')
        if pick not in valid_ids: raise ValueError('LLM podał recepturę spoza listy')
        rid=int(pick.split(':',1)[1])
        picked=next((x for x in scored if int(x.get('recipeId') or 0)==rid),None)
        if not picked: raise ValueError('Nie znaleziono wybranej receptury')

        default=scored[0]
        default_score=max(0.0001,float(default.get("brainScore") or 0))
        picked_score=float(picked.get("brainScore") or 0)
        sacrifice=max(0.0,(default_score-picked_score)/default_score*100.0)
        max_sac=max(0.0,float(cfg.get("max_score_sacrifice_pct") or 20))
        if sacrifice>max_sac:
            note=f"LLM chciał {picked.get('name')}, ale strata score {sacrifice:.1f}% > {max_sac:.1f}% — zostawiam wybór statystyczny"
            LAST_RECIPE_LLM_REVIEW_AT=time.time(); LAST_RECIPE_LLM_PICK=f"recipe:{int(default.get('recipeId') or 0)}"; LAST_RECIPE_LLM_NOTE=note
            LAST_LLM_STATUS={"status":"ONLINE","model":model,"last_error":"","last_review":LAST_RECIPE_LLM_REVIEW_AT}
            return default,note

        note=str(obj.get("reason") or "lokalny LLM wybrał recepturę")[:500]
        LAST_RECIPE_LLM_REVIEW_AT=time.time(); LAST_RECIPE_LLM_PICK=pick; LAST_RECIPE_LLM_NOTE=note
        LAST_LLM_STATUS={"status":"ONLINE","model":model,"last_error":"","last_review":LAST_RECIPE_LLM_REVIEW_AT}
        with db() as con:
            con.execute("INSERT INTO policy_reflections(ts,source,selected_action_key,note) VALUES(?,?,?,?)",(int(time.time()*1000),"local_llm_recipe",pick,note))
        return picked,note
    except Exception as e:
        LAST_LLM_STATUS={"status":"BŁĄD","model":model,"last_error":f"{type(e).__name__}: {e}","last_review":LAST_LLM_STATUS.get("last_review",0)}
        return None,f"LLM ekonomia: {type(e).__name__}"


# ----------------------------------------------------------------------
# OPTIONAL OPENAI ADVISOR
# ----------------------------------------------------------------------
def extract_response_text(resp: dict[str, Any]) -> str:
    parts = []
    for item in resp.get("output") or []:
        for c in item.get("content") or []:
            if c.get("type") in {"output_text", "text"} and c.get("text"):
                parts.append(str(c["text"]))
    return "\n".join(parts).strip()


def maybe_openai_advisor(memory: dict[str, Any], decision_summary: dict[str, Any]) -> str:
    global LAST_ADVISOR_AT, LAST_ADVISOR_NOTE

    cfg = CFG.get("openai_advisor") or {}
    if not cfg.get("enabled"):
        LAST_ADVISOR_NOTE = "OFF"
        return LAST_ADVISOR_NOTE

    key = os.environ.get("OPENAI_API_KEY", "").strip()
    if not key:
        LAST_ADVISOR_NOTE = "brak OPENAI_API_KEY"
        return LAST_ADVISOR_NOTE

    interval = max(5.0, float(cfg.get("interval_minutes") or 60)) * 60.0
    if time.time() - LAST_ADVISOR_AT < interval:
        return LAST_ADVISOR_NOTE

    prompt = {
        "role": "Jesteś okresowym doradcą strategii dla lokalnego agenta ekonomicznego w grze.",
        "rule": "Nie wydawaj bezpośrednich komend API. Wskaż najwyżej 3 krótkie obserwacje strategiczne. Nie sugeruj omijania zabezpieczeń, limitów ani mechanizmów antybot.",
        "memory": memory,
        "current_decision": decision_summary,
    }

    body = json.dumps({
        "model": str(cfg.get("model") or "gpt-5.4-mini"),
        "input": json.dumps(prompt, ensure_ascii=False),
        "max_output_tokens": int(cfg.get("max_output_tokens") or 500),
    }).encode("utf-8")

    req = urllib.request.Request(
        "https://api.openai.com/v1/responses",
        data=body,
        headers={
            "Authorization": f"Bearer {key}",
            "Content-Type": "application/json",
        },
        method="POST",
    )

    try:
        with urllib.request.urlopen(req, timeout=30) as r:
            resp = json.loads(r.read().decode("utf-8"))
        note = extract_response_text(resp)
        if note:
            LAST_ADVISOR_NOTE = note[:1200]
            LAST_ADVISOR_AT = time.time()
            log("OpenAI advisor: zaktualizowano notatkę strategiczną")
    except Exception as e:
        LAST_ADVISOR_NOTE = f"błąd advisor: {type(e).__name__}"
        log(f"OpenAI advisor error: {type(e).__name__}: {e}")

    return LAST_ADVISOR_NOTE


# ----------------------------------------------------------------------
# ACTION POLICY
# ----------------------------------------------------------------------
def menel_expected_hour(payload: dict[str,Any]) -> tuple[float,int]:
    world=payload.get("world") or {}; menel=world.get("menel") or {}; ch=payload.get("character") or {}
    district=str(menel.get("districtName") or ch.get("districtName") or "?")
    with db() as con:
        row=con.execute("SELECT * FROM menel_stats WHERE district=?",(district,)).fetchone()
    if row and row["mean_reward"] is not None:
        sec=max(60.0,float(row["mean_duration"] or menel.get("estimatedDuration") or 1139))
        return float(row["mean_reward"])/(sec/3600.0),int(row["runs"])
    sec=max(60.0,float(menel.get("estimatedDuration") or 1139))
    return 100.0/(sec/3600.0),0


def make_candidate(cid: str, action: dict[str,Any], group: str, base: float, stat_key: str, reason: str) -> dict[str,Any]:
    adjusted,conf,learn_reason=tuned_score(base,stat_key)
    return {"candidateId":cid,"action":action,"group":group,"baseScore":float(base),"adjustedScore":float(adjusted),"confidence":float(conf),"statKey":stat_key,"reason":f"{reason} • {learn_reason}","label":str(action.get("label") or action.get("type") or cid)}


def world_action_candidates(payload: dict[str,Any]) -> list[dict[str,Any]]:
    modules=payload.get("modules") or {}
    world=payload.get("world") or {}
    limits=payload.get("limits") or {}
    ch=payload.get("character") or {}

    menel=world.get("menel") or {}
    hustling=world.get("hustling") or {}
    travel_status=world.get("travelStatus") or {}
    active_hustle=hustling.get("activeSession")
    district=str(ch.get("districtName") or menel.get("districtName") or "")
    current_id=int(ch.get("currentDistrictId") or travel_status.get("currentDistrictId") or 0)

    if modules.get("menel") and (menel.get("lastMenelModeResult") or menel.get("pendingCompletion")):
        return [{
            "candidateId":"mandatory:menel_clear",
            "action":{"type":"menel_clear_result","label":"Zapisz i wyczyść wynik MenelMode","reason":"Gotowy/pending wynik blokuje następne cykle"},
            "group":"mandatory","baseScore":1e12,"adjustedScore":1e12,"confidence":1.0,
            "statKey":"mandatory:menel_clear","reason":"obowiązkowe sprzątanie stanu MenelMode","label":"Zapisz i wyczyść wynik MenelMode"
        }]

    if travel_status.get("traveling"):
        rem=float(travel_status.get("travelTimeRemaining") or 0)
        threshold=float(travel_status.get("vipFreeSpeedupThreshold") or 0)

        # v3.2.7: po zejściu czasu do zera serwer potrafi nadal zwracać
        # traveling=true + pendingArrival=true. Front wymaga wtedy osobnego
        # /api/travel/complete z instant:false („Wysiądź z autobusu”).
        if modules.get("travel") and travel_status.get("pendingArrival") and rem<=0:
            return [{
                "candidateId":"mandatory:travel_complete_arrival",
                "action":{"type":"travel_complete_arrival","label":"Wysiądź z autobusu","reason":"Podróż ma 0 s i serwer czeka na potwierdzenie przyjazdu"},
                "group":"mandatory","baseScore":1e12,"adjustedScore":1e12,"confidence":1.0,
                "statKey":"mandatory:travel_complete_arrival","reason":"pendingArrival blokuje MenelMode i sweep","label":"Wysiądź z autobusu"
            }]

        if modules.get("travel") and modules.get("freeTravelSpeedup") and threshold>0 and rem>0 and rem<=threshold:
            return [{
                "candidateId":"mandatory:travel_free_complete",
                "action":{"type":"travel_complete_free","label":f"Darmowo zakończ podróż ({rem:.0f}s ≤ {threshold:.0f}s)","reason":"Serwer podał darmowy próg przyspieszenia podróży"},
                "group":"mandatory","baseScore":1e12,"adjustedScore":1e12,"confidence":1.0,
                "statKey":"mandatory:travel_free_complete","reason":"darmowy próg podróży","label":"Darmowe zakończenie podróży"
            }]
        return []

    if menel.get("activeActivity") or menel.get("currentActivity") or menel.get("pendingCompletion"):
        return []

    sweep=district_sweep_state(payload,create=True)

    if (
        modules.get("districtSweep")
        and sweep.get("phase") in ("WAIT_COOLDOWNS","WAIT_TRAVEL_DATA","UNKNOWN")
    ):
        # Priorytet użytkownika: bez mapy białe/czerwone NIE przechodzimy
        # do NPC ani Kombinowania.
        return []

    if sweep.get("enabled") and sweep.get("phase")=="SWEEP" and sweep.get("remaining",0)>0:
        remaining=set(int(x) for x in sweep.get("remainingIds") or [])

        if active_hustle:
            tid=int(active_hustle.get("hustlingTypeId") or 0)
            return [make_candidate(
                f"hustle_stop:{tid}",
                {"type":"hustle_stop","label":"Przerwij kombinowanie — najpierw sweep dzielnic","reason":f"MenelMode sweep: zostało {len(remaining)} dzielnic"},
                "mandatory",1e11,action_key("hustle",tid,district),"twardy priorytet sweepu MenelMode"
            )]

        if current_id in remaining and modules.get("menel") and menel.get("canStart"):
            done=int(sweep.get("completed") or 0); total=int(sweep.get("total") or 0)
            return [{
                "candidateId":f"mandatory:menel_sweep:{current_id}",
                "action":{"type":"menel_start","label":f"MenelMode sweep: {district}","reason":f"Dzielnice {done}/{total}; ta dzielnica jest biała"},
                "group":"mandatory","baseScore":1e11,"adjustedScore":1e11,"confidence":1.0,
                "statKey":action_key("menel_sweep",current_id,district),"reason":"najpierw wszystkie białe dzielnice","label":f"MenelMode sweep: {district}"
            }]

        tt=world.get("travelTimes") or {}
        current_price=float((tt.get("currentDistrict") or {}).get("canPrice") or 0)
        cans=float(ch.get("cans") or 0)
        sell_min=float(limits.get("sellCansMin") or 0)
        target_price=min(0.15,max(0.01,float(limits.get("canTargetPrice") or 0.15)))
        if modules.get("cans") and cans>=sell_min and current_price>=target_price-1e-9:
            return [{
                "candidateId":f"mandatory:sweep_sell_cans:{current_id}",
                "action":{"type":"sell_cans","cans":int(cans),"label":f"Sprzedaj puszki po {current_price:.2f} zł podczas sweepu","reason":"Cena docelowa osiągnięta; sprzedaż nie blokuje MenelMode"},
                "group":"mandatory","baseScore":1e10,"adjustedScore":1e10,"confidence":1.0,
                "statKey":action_key("sell_cans",district,district),"reason":"15 gr jest znanym maksimum","label":"Sprzedaż puszek po cenie docelowej"
            }]

        target=choose_sweep_target(payload,sweep)
        if target and modules.get("travel"):
            tmin=float(target.get("travelTime") or 0); price=float(target.get("canPrice") or 0)
            current_red = current_id not in remaining
            return [{
                "candidateId":f"mandatory:sweep_travel:{int(target.get('id') or 0)}",
                "action":{"type":"travel","districtId":int(target.get("id") or 0),"districtName":str(target.get("name") or ""),"label":f"Sweep → {target.get('name')} ({tmin:.0f} min, puszki {price*100:.0f} gr)","reason":(
                    f"Aktualna dzielnica jest już czerwona/zrobiona — podróż do następnej białej; zostało {len(remaining)}"
                    if current_red else
                    f"Najbliższa pozostała biała dzielnica; zostało {len(remaining)}"
                )},
                "group":"mandatory","baseScore":1e10,"adjustedScore":1e10,"confidence":1.0,
                "statKey":action_key("travel_sweep",int(target.get("id") or 0),district),"reason":"twardy priorytet białych dzielnic","label":f"Sweep → {target.get('name')}"
            }]

        return []

    if active_hustle:
        elapsed=float(active_hustle.get("elapsedSeconds") or 0)/60.0
        target=max(15.0,float(limits.get("hustleSessionMinutes") or 60))
        if elapsed>=target:
            tid=int(active_hustle.get("hustlingTypeId") or 0)
            return [make_candidate(
                f"hustle_stop:{tid}",
                {"type":"hustle_stop","label":f"Zakończ kombinowanie po {elapsed:.0f} min","reason":"Potrzebny realny wynik do uczenia"},
                "mandatory",1e9,action_key("hustle",tid,district),"zakończenie próbki"
            )]
        return []

    out=[]
    travel_action=travel_or_can_action(payload)

    if travel_action and travel_action.get("type")=="sell_cans":
        price=float(as_dict(as_dict(world.get("travelTimes")).get("currentDistrict")).get("canPrice") or 0)
        out.append(make_candidate(f"sell_cans:{district}",travel_action,"instant",max(1.0,price),action_key("sell_cans",district,district),travel_action.get("reason") or "sprzedaż puszek"))

    # v3.2.7: NPC nie konkuruje z głównym torem; dodano obowiązkowe potwierdzenie pendingArrival.
    # Jest wybierany osobno przez choose_side_actions() i może działać równolegle
    # z MenelMode oraz Kombinowaniem.

    if not modules.get("districtSweep") and modules.get("menel") and menel.get("canStart"):
        mph,samples=menel_expected_hour(payload)
        out.append(make_candidate(f"menel:{district}",{"type":"menel_start","label":f"Start MenelMode: {district}","reason":f"oczekiwane ~{mph:.1f} zł/h"},"blocking",mph,action_key("menel",district,district),f"MenelMode • {samples} prób"))

    if modules.get("hustling"):
        best=best_hustle(hustling)
        if best:
            tid=int(best.get("id") or 0)
            hustle_score = 1e7
            out.append(make_candidate(
                f"hustle:{tid}",
                {"type":"hustle_start","hustlingTypeId":tid,"label":f"Kombinowanie: {best.get('displayName')}","reason":f"sweep dzielnic zakończony • oczekiwane ~{best['brainExpectedHour']:.1f} zł/h"},
                "blocking",hustle_score,action_key("hustle",tid,district),"wszystkie dzielnice z bieżącego sweepu zrobione"
            ))

    if travel_action and travel_action.get("type")=="travel":
        target=int(travel_action.get("districtId") or 0)
        row=next((x for x in ((world.get("travelTimes") or {}).get("districts") or []) if int(x.get("id") or 0)==target),None)
        sec=max(60.0,float((row or {}).get("travelTime") or 12)*60.0)
        gain=max(1.0,float(travel_action.get("utility") or 1))
        hourly=gain/(sec/3600.0)
        out.append(make_candidate(f"travel:{target}",travel_action,"blocking",hourly,action_key("travel",target,district),f"podróż • wartość ~{hourly:.1f}/h"))

    if modules.get("collections"):
        col=collection_candidate(payload)
        if col:
            out.append(make_candidate(f"collection:{col['collectionId']}:{col['itemId']}",{"type":"collection_deposit","collectionId":col["collectionId"],"itemId":col["itemId"],"label":f"Kolekcja {col['collectionName']}: {col['itemName']}","reason":f"wartość ~{col['value']:.0f} zł"},"maintenance",max(0.1,float(col["score"])),action_key("collection",col["collectionId"],district),"tani postęp kolekcji"))

    if modules.get("favors"):
        fav=favor_candidate(payload)
        if fav:
            fid=int(fav.get("id") or 0)
            out.append(make_candidate(f"favor:{fid}",{"type":"favor_activate","favorOwnedId":fid,"label":f"Aktywuj tanią przysługę: {fav.get('name')}","reason":f"utility {fav['brainUtility']:.1f}"},"maintenance",max(0.1,float(fav["brainUtility"])),action_key("favor",fid,district),"tania karta może odblokować NPC"))

    return out


def select_candidate(payload: dict[str,Any], candidates: list[dict[str,Any]]) -> tuple[dict[str,Any]|None,str]:
    if not candidates: return None,"brak kandydatów"
    mandatory=[x for x in candidates if x["group"]=="mandatory"]
    if mandatory: return mandatory[0],"akcja obowiązkowa"
    pool=[x for x in candidates if x["group"]=="instant"] or [x for x in candidates if x["group"]=="blocking"] or [x for x in candidates if x["group"]=="maintenance"]
    if not pool: return None,"brak grupy"
    pool.sort(key=lambda x:x["adjustedScore"],reverse=True); default=pool[0]; note="planner statystyczny"
    if (payload.get("modules") or {}).get("localLlmAdvice"):
        pick,llm_note=local_llm_review(pool,{"district":(payload.get("character") or {}).get("districtName"),"money":(payload.get("character") or {}).get("money"),"cans":(payload.get("character") or {}).get("cans"),"energy":(payload.get("character") or {}).get("energy"),"group":default["group"]})
        if pick:
            chosen=next((x for x in pool if str(x["candidateId"])==str(pick)),None)
            if chosen:
                sacrifice=0.0 if default["adjustedScore"]<=0 else max(0.0,(default["adjustedScore"]-chosen["adjustedScore"])/default["adjustedScore"]*100.0)
                max_sac=max(0.0,float((CFG.get("local_llm") or {}).get("max_score_sacrifice_pct") or 20))
                if sacrifice<=max_sac: return chosen,f"lokalny LLM: {llm_note}"
                note=f"LLM odrzucony: strata {sacrifice:.1f}%"
    return default,note


def choose_side_actions(payload: dict[str, Any], primary_action: dict[str, Any] | None = None) -> list[dict[str, Any]]:
    """Niezależne tory akcji.

    v3.2.7: NPC może być wykonywany równolegle z aktywnym MenelMode lub
    Kombinowaniem. Nie uruchamiamy go podczas podróży ani równolegle z akcją
    rozpoczynającą/kończącą podróż. Serwerowy returnCooldown i cooldown NPC są
    nadal źródłem prawdy.
    """
    modules=payload.get("modules") or {}
    world=payload.get("world") or {}
    travel_status=world.get("travelStatus") or {}
    primary_type=str((primary_action or {}).get("type") or "")

    if travel_status.get("traveling") or primary_type in {"travel","travel_complete_free","travel_complete_arrival"}:
        return []

    out=[]
    if modules.get("npc"):
        npc=choose_npc(payload)
        if npc:
            nid=int(npc.get("id") or 0)
            if not (primary_type=="npc_attack" and nid==int((primary_action or {}).get("npcId") or 0)):
                out.append({
                    "type":"npc_attack",
                    "npcId":nid,
                    "label":f"Atak NPC równolegle: {npc.get('name')}",
                    "reason":f"niezależny tor NPC • oczekiwane {npc['brainReward']:.1f} zł • reward/energia {npc['brainScore']:.2f}",
                    "candidateId":f"side:npc:{nid}",
                    "plannerScore":1e8,
                    "plannerConfidence":1.0,
                    "plannerReason":"NPC może działać równolegle z MenelMode i Kombinowaniem",
                    "plannerSource":"tor równoległy"
                })
    return out[:1]


def choose_world_action(payload: dict[str, Any]) -> dict[str, Any] | None:
    selected,note=select_candidate(payload,world_action_candidates(payload))
    if not selected: return None
    action=dict(selected["action"])
    action.update({"candidateId":selected["candidateId"],"plannerScore":selected["adjustedScore"],"plannerConfidence":selected["confidence"],"plannerReason":selected["reason"],"plannerSource":note})
    return action


def memory_summary() -> dict[str, Any]:
    with db() as con:
        recipes = con.execute(
            """
            SELECT recipe_id,name,sold,returned,mean_profit_hour,mean_sale_minutes
            FROM recipe_stats
            ORDER BY COALESCE(mean_profit_hour,-1) DESC LIMIT 10
            """
        ).fetchall()

        menel = con.execute(
            """
            SELECT district,runs,mean_reward,mean_cash,mean_cans,mean_item_value,mean_duration
            FROM menel_stats
            ORDER BY COALESCE(mean_reward,-1) DESC
            """
        ).fetchall()

        hustling = con.execute(
            """
            SELECT type_id,name,runs,interrupted,mean_earnings_hour,mean_minutes
            FROM hustling_stats
            ORDER BY COALESCE(mean_earnings_hour,-1) DESC
            """
        ).fetchall()

        npcs = con.execute(
            """
            SELECT npc_id,name,attacks,wins,mean_reward,mean_energy,mean_reward_energy
            FROM npc_stats
            ORDER BY COALESCE(mean_reward_energy,-1) DESC
            LIMIT 10
            """
        ).fetchall()

        cans = con.execute(
            """
            SELECT district,sales,mean_price,mean_amount,mean_earnings
            FROM can_sales
            ORDER BY COALESCE(mean_price,-1) DESC
            """
        ).fetchall()

        raids = con.execute(
            """
            SELECT location_id,name,observations,completed,successes,mean_money,mean_duration_minutes
            FROM raid_stats
            ORDER BY COALESCE(mean_money,-1) DESC
            """
        ).fetchall()

        actions = con.execute(
            "SELECT action_key,action_type,context,samples,successes,failures,mean_reward,ema_reward,mean_duration,last_ts FROM action_stats ORDER BY samples DESC, COALESCE(ema_reward,-1) DESC LIMIT 30"
        ).fetchall()

        n_events = con.execute("SELECT COUNT(*) n FROM seen_events").fetchone()["n"]
        n_decisions = con.execute("SELECT COUNT(*) n FROM decisions").fetchone()["n"]
        n_snapshots = con.execute("SELECT COUNT(*) n FROM world_snapshots").fetchone()["n"]

    return {
        "events": int(n_events),
        "decisions": int(n_decisions),
        "snapshots": int(n_snapshots),
        "recipes": [dict(x) for x in recipes],
        "menel": [dict(x) for x in menel],
        "hustling": [dict(x) for x in hustling],
        "npcs": [dict(x) for x in npcs],
        "cans": [dict(x) for x in cans],
        "raids": [dict(x) for x in raids],
        "actions": [dict(x) for x in actions],
        "db": str(DB_PATH),
    }


def decide(payload: dict[str, Any]) -> dict[str, Any]:
    decision_started = time.perf_counter()

    # NIGHT-SAFE v3.2.3: userscript celowo wysyła nieznane jeszcze sekcje jako null.
    # JSON null nie może wywrócić całego Braina przez chained .get().
    payload = as_dict(payload)
    world = as_dict(payload.get("world"))
    payload = dict(payload)
    payload["world"] = world

    added_legacy = ingest_recipe_events(payload.get("learnerEvents") or [])
    ack_ids = ingest_game_events(payload.get("gameEvents") or [])
    ingest_policy_events(payload.get("gameEvents") or [])
    learned_menel = ingest_menel_result((payload.get("world") or {}).get("menel"))
    ingest_raid(payload.get("world") or {})
    save_world_snapshot(payload)

    best, scored = choose_recipe(payload.get("candidates") or [])
    action = choose_world_action(payload)
    side_actions = choose_side_actions(payload, action)

    recipe_llm_note = ""
    if (
        not action
        and (payload.get("modules") or {}).get("localLlmAdvice")
        and scored
    ):
        reviewed_recipe, recipe_llm_note = local_llm_review_recipes(scored, payload)
        if reviewed_recipe is not None:
            best = reviewed_recipe

    if best:
        samples = int(best.get("brainSamples") or 0)
        confidence = 1.0 - math.exp(-samples / 5.0)
        hist = best.get("brainHistoricalProfitHour")
        bits = [
            f"ekonomia {best['brainScore']:.0f} zł/h",
            f"próbki {samples}",
            f"sprzedaż {best['brainSuccess']*100:.0f}%",
        ]
        if hist is not None:
            bits.append(f"historycznie {float(hist):.0f} zł/h")
        if recipe_llm_note:
            bits.append(f"LLM: {recipe_llm_note}")
        preferred_id = int(best["recipeId"])
        preferred_name = str(best.get("name") or "")
        recipe_score = float(best["brainScore"])
    else:
        confidence = 0.0
        bits = ["brak bezpiecznego craftu"]
        preferred_id = None
        preferred_name = ""
        recipe_score = None

    if action:
        bits.append(f"świat: {action.get('label')}")
        if action.get("plannerSource"):
            bits.append(str(action.get("plannerSource")))
    if side_actions:
        bits.append("równolegle: " + ", ".join(str(x.get("label") or x.get("type") or "") for x in side_actions))
    reason = " • ".join(bits)

    raid_rec = raid_recommendation(payload)
    tasks = task_hint(payload)

    memory = memory_summary()
    advisor = maybe_openai_advisor(
        memory={
            "recipes": memory["recipes"][:5],
            "menel": memory["menel"][:5],
            "hustling": memory["hustling"][:5],
            "npcs": memory["npcs"][:5],
            "cans": memory["cans"][:5],
            "raids": memory["raids"][:5],
        },
        decision_summary={
            "preferredRecipe": preferred_name,
            "recipeScore": recipe_score,
            "nextAction": action,
            "sideActions": side_actions,
            "raidRecommendation": raid_rec,
            "taskHint": tasks,
        }
    )

    with LOCK, db() as con:
        con.execute(
            """
            INSERT INTO decisions(
              ts,preferred_recipe_id,preferred_recipe_name,recipe_score,
              action_type,action_label,reason
            ) VALUES(?,?,?,?,?,?,?)
            """,
            (
                int(time.time() * 1000),
                preferred_id,
                preferred_name,
                recipe_score,
                str((action or {}).get("type") or "none"),
                str((action or {}).get("label") or ""),
                reason,
            ),
        )

    if added_legacy:
        log(f"Learned {added_legacy} economic outcome(s)")
    if learned_menel:
        log("Learned new MenelMode result")
    decision_ms = (time.perf_counter() - decision_started) * 1000.0

    if best or action or side_actions:
        side_label=", ".join(str(x.get("label") or x.get("type") or "") for x in side_actions) or "-"
        log(
            f"Decision: recipe={preferred_name or '-'} | "
            f"action={(action or {}).get('label','-')} | side={side_label} | {decision_ms:.0f} ms"
        )

    return {
        "ok": True,
        "brainVersion": "3.2.7",
        "ackEventIds": ack_ids,
        "decision": {
            "preferredRecipeId": preferred_id,
            "preferredRecipeName": preferred_name,
            "recipeScore": recipe_score,
            "confidence": confidence,
            "reason": reason,
            "nextAction": action,
            "sideActions": side_actions,
            "raidRecommendation": raid_rec,
            "taskHint": tasks,
            "advisorNote": advisor,
        },
        "brainStatus": {
            "plannerMode":"adaptive-bandit",
            "health":BRAIN_HEALTH,
            "localLlm":LAST_LLM_STATUS,
            "dbIntegrity":db_integrity(),
            "decisionMs":round(decision_ms,1),
            "districtSweep":LAST_DISTRICT_SWEEP,
            "npcReturnCooldown":as_dict(world.get("npcStatus")).get("returnCooldown") or {},
            "npcCooldowns":as_dict(world.get("npcStatus")).get("npcCooldowns") or [],
            "cooldownMapReceived":bool(as_dict(world.get("allCooldowns")).get("success")),
            "cooldownMapSource":str(world.get("allCooldownsSource") or ""),
            "parallelLanes":{"npc":True,"garden":"userscript"}
        },
        "memory": memory,
        "top": scored[:5],
        "learnedNow": {
            "legacyEconomicEvents": added_legacy,
            "gameEvents": len(ack_ids),
            "menelResult": learned_menel,
        },
    }


def json_bytes(obj: Any) -> bytes:
    return json.dumps(obj, ensure_ascii=False, separators=(",", ":")).encode("utf-8")


class Handler(BaseHTTPRequestHandler):
    server_version = "PomagierAI/3.2.7"

    def log_message(self, format: str, *args: Any) -> None:
        return

    def cors(self) -> None:
        origin = self.headers.get("Origin", "")
        if origin == "https://menelgame.online":
            self.send_header("Access-Control-Allow-Origin", origin)
        else:
            self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Vary", "Origin")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.send_header("Access-Control-Allow-Private-Network", "true")
        self.send_header("Cache-Control", "no-store")

    def do_OPTIONS(self) -> None:
        self.send_response(204)
        self.cors()
        self.end_headers()

    def send_json(self, code: int, obj: Any) -> bool:
        data = json_bytes(obj)
        try:
            self.send_response(code)
            self.cors()
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.send_header("Content-Length", str(len(data)))
            self.end_headers()
            self.wfile.write(data)
            try:
                self.wfile.flush()
            except Exception:
                pass
            return True
        except (BrokenPipeError, ConnectionResetError, ConnectionAbortedError) as e:
            log(f"CLIENT DISCONNECTED before response: {type(e).__name__}")
            return False
        except OSError as e:
            if getattr(e, "winerror", None) in (10053, 10054):
                log(f"CLIENT DISCONNECTED before response: WinError {e.winerror}")
                return False
            raise

    def read_json(self) -> dict[str, Any]:
        n = int(self.headers.get("Content-Length", "0") or 0)
        if n <= 0 or n > 5_000_000:
            raise ValueError("Nieprawidłowy rozmiar JSON")
        obj = json.loads(self.rfile.read(n).decode("utf-8"))
        if not isinstance(obj, dict):
            raise ValueError("JSON musi być obiektem")
        return obj

    def authorized(self, payload: dict[str, Any]) -> bool:
        expected = str(CFG.get("bridge_token") or "")
        got = str(payload.get("bridgeToken") or "")
        # Stałoczasowe porównanie hashy.
        return (
            bool(expected) and
            hashlib.sha256(got.encode()).digest() ==
            hashlib.sha256(expected.encode()).digest()
        )

    def do_POST(self) -> None:
        if self.path != "/v1/decide":
            self.send_json(404, {"ok": False, "error": "not found"})
            return

        try:
            payload = self.read_json()
            if not self.authorized(payload):
                self.send_json(403, {"ok": False, "error": "bad bridge token"})
                return

            response = decide(payload)
            self.send_json(200, response)

        except (BrokenPipeError, ConnectionResetError, ConnectionAbortedError):
            return
        except OSError as e:
            if getattr(e, "winerror", None) in (10053, 10054):
                log(f"CLIENT DISCONNECTED during request: WinError {e.winerror}")
                return
            log(f"ERROR: {type(e).__name__}: {e}")
            self.send_json(500, {"ok": False, "error": f"{type(e).__name__}: {e}"})
        except Exception as e:
            log(f"ERROR: {type(e).__name__}: {e}")
            # Zapis stosu do logu, żeby pojedynczy błąd nocny dało się później
            # naprawić bez zgadywania. Odpowiedź HTTP nadal pozostaje krótka.
            for line in traceback.format_exc(limit=12).rstrip().splitlines():
                log(f"TRACE: {line}")
            self.send_json(500, {"ok": False, "error": f"{type(e).__name__}: {e}"})

    def do_GET(self) -> None:
        if self.path == "/health":
            self.send_json(200, {
                "ok": True,
                "brainVersion": "3.2.7",
                "time": int(time.time() * 1000),
                "memory": memory_summary(),
                "openaiAdvisor": LAST_ADVISOR_NOTE,
            })
            return

        if self.path == "/v1/memory":
            self.send_json(200, {"ok": True, "memory": memory_summary()})
            return

        if self.path == "/":
            mem = memory_summary()

            def table(rows, cols):
                if not rows:
                    return "<tr><td colspan='9'>Brak danych — AI zbiera pierwsze próbki.</td></tr>"
                out = []
                for r in rows:
                    out.append("<tr>" + "".join(
                        f"<td>{html.escape(str(r.get(c,'')))}</td>" for c in cols
                    ) + "</tr>")
                return "".join(out)

            page = f"""<!doctype html>
<html lang="pl"><meta charset="utf-8"><title>Pomagier AI Brain v3.2.7</title>
<style>
body{{font-family:system-ui;background:#121416;color:#e8eaed;margin:30px;max-width:1300px}}
.card{{background:#1d2226;border:1px solid #39434a;border-radius:12px;padding:16px;margin:12px 0;overflow:auto}}
.ok{{color:#66d58a}} table{{border-collapse:collapse;width:100%}} th,td{{border-bottom:1px solid #343a40;padding:7px;text-align:left;font-size:13px}}
small{{color:#9aa0a6}} h2{{margin-top:4px}}
</style>
<h1>🧠 Pomagier AI Brain v3.2.7 <span class="ok">ONLINE</span></h1>
<div class="card">
Pamięć: <b>{mem['events']}</b> zdarzeń • <b>{mem['decisions']}</b> decyzji •
<b>{mem['snapshots']}</b> snapshotów świata<br>
<small>DB: {html.escape(mem['db'])}</small><br>
<small>OpenAI advisor: {html.escape(LAST_ADVISOR_NOTE)}</small><br>
<small>Lokalny LLM: {html.escape(str(LAST_LLM_STATUS.get('status')))} {html.escape(str(LAST_LLM_STATUS.get('model') or ''))}</small><br>
<small>DB integrity: {html.escape(db_integrity())}</small><br>
<small>Bridge: odporny na rozłączenie klienta 10053/10054</small>
</div>

<div class="card"><h2>Ekonomia</h2><table>
<tr><th>recipe_id</th><th>name</th><th>sold</th><th>returned</th><th>mean_profit_hour</th><th>mean_sale_minutes</th></tr>
{table(mem['recipes'],['recipe_id','name','sold','returned','mean_profit_hour','mean_sale_minutes'])}
</table></div>

<div class="card"><h2>MenelMode</h2><table>
<tr><th>district</th><th>runs</th><th>mean_reward</th><th>mean_cash</th><th>mean_cans</th><th>mean_duration</th></tr>
{table(mem['menel'],['district','runs','mean_reward','mean_cash','mean_cans','mean_duration'])}
</table></div>

<div class="card"><h2>Kombinowanie</h2><table>
<tr><th>type_id</th><th>name</th><th>runs</th><th>interrupted</th><th>mean_earnings_hour</th><th>mean_minutes</th></tr>
{table(mem['hustling'],['type_id','name','runs','interrupted','mean_earnings_hour','mean_minutes'])}
</table></div>

<div class="card"><h2>NPC</h2><table>
<tr><th>npc_id</th><th>name</th><th>attacks</th><th>wins</th><th>mean_reward</th><th>mean_energy</th><th>mean_reward_energy</th></tr>
{table(mem['npcs'],['npc_id','name','attacks','wins','mean_reward','mean_energy','mean_reward_energy'])}
</table></div>

<div class="card"><h2>Puszki</h2><table>
<tr><th>district</th><th>sales</th><th>mean_price</th><th>mean_amount</th><th>mean_earnings</th></tr>
{table(mem['cans'],['district','sales','mean_price','mean_amount','mean_earnings'])}
</table></div>

<div class="card"><h2>Napady — obserwacja</h2><table>
<tr><th>location_id</th><th>name</th><th>observations</th><th>completed</th><th>successes</th><th>mean_money</th><th>mean_duration_minutes</th></tr>
{table(mem['raids'],['location_id','name','observations','completed','successes','mean_money','mean_duration_minutes'])}
</table></div>

<div class="card"><h2>Samouczenie polityki decyzji</h2><table>
<tr><th>action_key</th><th>type</th><th>context</th><th>samples</th><th>successes</th><th>failures</th><th>mean_reward</th><th>ema_reward</th></tr>
{table(mem['actions'],['action_key','action_type','context','samples','successes','failures','mean_reward','ema_reward'])}
</table></div>

<div class="card"><small>
AI Brain nie posiada cookies ani tokenów Menelgame. Nasłuchuje tylko na 127.0.0.1.
Napady są obecnie tylko analizowane/rekomendowane, bo w naszych przechwyconych requestach
nie ma jeszcze potwierdzonego zwykłego endpointu POST do rozpoczęcia napadu.
</small></div>
</html>"""

            data = page.encode("utf-8")
            self.send_response(200)
            self.cors()
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.send_header("Content-Length", str(len(data)))
            self.end_headers()
            self.wfile.write(data)
            return

        self.send_json(404, {"ok": False, "error": "not found"})


def main() -> None:
    global BRAIN_HEALTH, LAST_LLM_STATUS
    init_db()
    integrity=db_integrity()
    BRAIN_HEALTH="OK" if integrity=="ok" else f"DB:{integrity}"
    maintenance_backup()

    host = str(CFG.get("bind") or "127.0.0.1")
    port = int(CFG.get("port") or 8765)

    if host not in {"127.0.0.1", "localhost"}:
        raise SystemExit("Dla bezpieczeństwa bind musi być 127.0.0.1 albo localhost.")

    server = ThreadingHTTPServer((host, port), Handler)
    server.daemon_threads = True
    log(f"Pomagier AI Brain v3.2.7 ONLINE: http://{host}:{port}")
    log(f"Dashboard: http://{host}:{port}/")

    llm_cfg=CFG.get("local_llm") or {}
    detected_model=local_llm_model()
    if llm_cfg.get("enabled",True) and detected_model:
        LAST_LLM_STATUS={"status":"READY","model":detected_model,"last_error":"","last_review":0}
    elif llm_cfg.get("enabled",True):
        LAST_LLM_STATUS={"status":"BRAK MODELU","model":"","last_error":"Ollama niedostępna albo brak modelu","last_review":0}
    else:
        LAST_LLM_STATUS={"status":"OFF","model":"","last_error":"","last_review":0}
    log(f"Local LLM reviewer: {'ON' if llm_cfg.get('enabled',True) else 'OFF'} • model={detected_model or 'AUTO/BRAK'}")

    oa = CFG.get("openai_advisor") or {}
    if oa.get("enabled"):
        log("OpenAI advisor: ON (klucz tylko z OPENAI_API_KEY)")
    else:
        log("OpenAI advisor: OFF")

    try:
        server.serve_forever(poll_interval=0.5)
    except KeyboardInterrupt:
        log("Zatrzymano przez użytkownika.")
    finally:
        server.server_close()


if __name__ == "__main__":
    main()
